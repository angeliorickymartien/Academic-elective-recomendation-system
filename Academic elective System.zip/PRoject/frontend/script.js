/**
 * Academic Elective Recommendation System - Frontend Controller
 * Indian Higher Education System (NEP 2020 & CBCS Aligned)
 * 
 * Connected directly to Python Flask REST API: POST /api/recommend
 */

// =============================================================================
// 1. BACKEND API CONFIGURATION
// =============================================================================
const API_CONFIG = {
  endpoint: (window.location.protocol.startsWith('http'))
    ? `${window.location.origin}/api/recommend`
    : 'http://127.0.0.1:5000/api/recommend',
  timeoutMs: 8000
};

// =============================================================================
// 2. DEGREE-WISE ADAPTIVE SUGGESTION DATA (UI HELPERS)
// =============================================================================
const DEGREE_SUGGESTIONS = {
  "BCA": {
    interests: ["Web Technologies", "Cloud Architecture", "Information Security", "Mobile App Development", "Data Analytics", "Artificial Intelligence"],
    skills: ["Python", "Java", "C / C++", "SQL & Databases", "HTML / CSS / JavaScript", "Data Structures & Algorithms", "Git & GitHub"],
    subjects: ["Database Management Systems", "Operating Systems", "Computer Networks", "Software Engineering", "Java Programming"]
  },
  "B.Sc Computer Science": {
    interests: ["Artificial Intelligence", "Data Analytics", "Cloud Architecture", "Information Security", "Web Technologies"],
    skills: ["Python", "C / C++", "Data Structures & Algorithms", "SQL & Databases", "Linux & Shell Scripting", "Machine Learning"],
    subjects: ["Data Structures", "Theory of Computation", "Computer Networks", "Operating Systems", "Discrete Mathematics"]
  },
  "B.Com": {
    interests: ["Financial Accounting", "Corporate Finance", "Business Strategy", "Economic Policies", "Data Analytics"],
    skills: ["Advanced Excel", "Tally Prime & GST", "Financial Modelling", "Business Communication", "Tableau / Power BI"],
    subjects: ["Financial Accounting", "Corporate Accounting", "Cost & Management Accounting", "Income Tax Law", "Company Law"]
  },
  "BBA": {
    interests: ["Business Strategy", "Digital Marketing", "Corporate Finance", "Operations Management", "Economic Policies"],
    skills: ["Business Communication", "Advanced Excel", "Financial Modelling", "Tableau / Power BI", "Git & GitHub"],
    subjects: ["Principles of Management", "Marketing Management", "Financial Management", "Organizational Behaviour", "Business Law"]
  },
  "B.A.": {
    interests: ["Indian Polity & Governance", "Public Administration", "Economic Policies", "Business Strategy", "Data Analytics"],
    skills: ["Business Communication", "Statistical Analysis", "Advanced Excel", "Linux & Shell Scripting"],
    subjects: ["Indian Government and Politics", "Public Policy", "Macroeconomics", "Modern Indian History", "Sociological Foundations"]
  },
  "B.Tech": {
    interests: ["Artificial Intelligence", "Cloud Architecture", "Information Security", "Web Technologies", "Data Analytics", "Mobile App Development"],
    skills: ["Python", "C / C++", "Java", "Data Structures & Algorithms", "Git & GitHub", "Linux & Shell Scripting", "SQL & Databases", "Machine Learning"],
    subjects: ["Data Structures & Algorithms", "Operating Systems", "Computer Organization", "Database Systems", "Computer Networks"]
  }
};

// =============================================================================
// 3. STATE & DOM REFERENCES
// =============================================================================
const state = {
  selectedInterests: new Set(),
  selectedSkills: new Set(),
  lastRecommendations: []
};

const dom = {
  form: document.getElementById('electiveForm'),
  studentName: document.getElementById('studentName'),
  degreeProgramme: document.getElementById('degreeProgramme'),
  currentSemester: document.getElementById('currentSemester'),
  careerGoal: document.getElementById('careerGoal'),
  favouriteSubjects: document.getElementById('favouriteSubjects'),
  hiddenInterests: document.getElementById('selectedInterests'),
  hiddenSkills: document.getElementById('selectedSkills'),

  academicYearDisplay: document.getElementById('academicYearDisplay'),
  ayLabel: document.getElementById('ayLabel'),
  ayBadge: document.getElementById('ayBadge'),

  interestCount: document.getElementById('interestCount'),
  skillsCount: document.getElementById('skillsCount'),

  interestsContainer: document.getElementById('academicInterestsChips'),
  skillsContainer: document.getElementById('technicalSkillsChips'),
  quickSuggestions: document.getElementById('quickSubjectSuggestions'),

  formAlert: document.getElementById('formAlert'),
  alertMessage: document.getElementById('alertMessage'),

  submitBtn: document.getElementById('submitFormBtn'),
  resetBtn: document.getElementById('resetFormBtn'),

  loadingSection: document.getElementById('loadingSection'),
  loadingStatusText: document.getElementById('loadingStatusText'),
  loadingSubtext: document.getElementById('loadingSubtext'),
  loadingProgressBar: document.getElementById('loadingProgressBar'),
  lStep1: document.getElementById('lStep1'),
  lStep2: document.getElementById('lStep2'),
  lStep3: document.getElementById('lStep3'),
  lStep4: document.getElementById('lStep4'),

  resultsSection: document.getElementById('recommendations'),
  resStudentName: document.getElementById('resStudentName'),
  resDegree: document.getElementById('resDegree'),
  resSemester: document.getElementById('resSemester'),
  resAcademicYear: document.getElementById('resAcademicYear'),
  resCareerGoal: document.getElementById('resCareerGoal'),
  cardsContainer: document.getElementById('electiveCardsContainer'),
  printBtn: document.getElementById('printResultsBtn'),
  modifyBtn: document.getElementById('modifyPreferencesBtn'),

  // Syllabus Modal Elements
  syllabusModal: document.getElementById('syllabusModal'),
  modalSubjectCode: document.getElementById('modalSubjectCode'),
  modalSubjectName: document.getElementById('modalSubjectName'),
  modalBodyContent: document.getElementById('modalBodyContent'),
  modalCreditBadge: document.getElementById('modalCreditBadge'),
  closeModalBtn: document.getElementById('closeModalBtn'),
  modalDoneBtn: document.getElementById('modalDoneBtn'),

  // Navigation
  mobileMenuBtn: document.getElementById('mobileMenuBtn'),
  navLinks: document.getElementById('navLinks')
};

// =============================================================================
// 4. INITIALIZATION
// =============================================================================
document.addEventListener('DOMContentLoaded', () => {
  setupNavigation();
  setupSemesterAcademicYearSync();
  setupDegreeAdaptiveSuggestions();
  setupChipSelection();
  setupQuickSubjectBadges();
  setupFormValidationAndSubmission();
  setupModalHandlers();
  setupPrintHandler();
});

// -----------------------------------------------------------------------------
// Navigation Bar & Mobile Menu
// -----------------------------------------------------------------------------
function setupNavigation() {
  if (dom.mobileMenuBtn && dom.navLinks) {
    dom.mobileMenuBtn.addEventListener('click', () => {
      dom.navLinks.classList.toggle('mobile-open');
    });

    dom.navLinks.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => {
        dom.navLinks.classList.remove('mobile-open');
      });
    });
  }

  // Active link highlighter on scroll
  const sections = document.querySelectorAll('section[id]');
  window.addEventListener('scroll', () => {
    const scrollY = window.pageYOffset + 120;
    sections.forEach(current => {
      const sectionHeight = current.offsetHeight;
      const sectionTop = current.offsetTop;
      const sectionId = current.getAttribute('id');
      const targetNav = document.querySelector(`.nav-links a[href*='${sectionId}']`);
      if (targetNav) {
        if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
          document.querySelectorAll('.nav-links .nav-link').forEach(l => l.classList.remove('active'));
          targetNav.classList.add('active');
        }
      }
    });
  }, { passive: true });
}

// -----------------------------------------------------------------------------
// Indian Academic Year Synchronization
// -----------------------------------------------------------------------------
function setupSemesterAcademicYearSync() {
  dom.currentSemester.addEventListener('change', () => {
    const sem = parseInt(dom.currentSemester.value, 10);
    if (!sem) {
      dom.ayLabel.textContent = "Please select a semester";
      dom.ayBadge.textContent = "Not Selected";
      dom.academicYearDisplay.classList.remove('active');
      return;
    }

    let yearText = "";
    let badgeText = "";
    const degree = dom.degreeProgramme.value;

    switch (sem) {
      case 1:
      case 2:
        yearText = "1st Academic Year (Foundation / Introductory Level)";
        badgeText = "1st Year UG";
        break;
      case 3:
      case 4:
        yearText = "2nd Academic Year (Core & Skill Enhancement Level)";
        badgeText = "2nd Year UG";
        break;
      case 5:
      case 6:
        yearText = "3rd Academic Year (Discipline-Specific Electives Level)";
        badgeText = "3rd Year UG";
        break;
      case 7:
      case 8:
        if (degree === "B.Tech") {
          yearText = "4th Academic Year (Advanced Engineering & Capstone Project)";
          badgeText = "Final Year B.Tech";
        } else {
          yearText = "4th Academic Year (NEP 2020 Honours with Research Track)";
          badgeText = "Honours 4th Year";
        }
        break;
      default:
        yearText = "Undergraduate Programme";
        badgeText = "UG Level";
    }

    dom.ayLabel.textContent = yearText;
    dom.ayBadge.textContent = badgeText;
    dom.academicYearDisplay.classList.add('active');
  });
}

// -----------------------------------------------------------------------------
// Degree Adaptive Suggestions
// -----------------------------------------------------------------------------
function setupDegreeAdaptiveSuggestions() {
  dom.degreeProgramme.addEventListener('change', () => {
    const selectedDegree = dom.degreeProgramme.value;
    const suggestions = DEGREE_SUGGESTIONS[selectedDegree];

    if (dom.currentSemester.value) {
      dom.currentSemester.dispatchEvent(new Event('change'));
    }

    if (!suggestions) return;

    if (dom.quickSuggestions) {
      dom.quickSuggestions.innerHTML = '<span class="suggest-label">Curriculum suggestions:</span>';
      suggestions.subjects.forEach(subj => {
        const span = document.createElement('span');
        span.className = 'suggest-badge';
        span.setAttribute('data-subject', subj);
        span.textContent = subj;
        span.addEventListener('click', () => appendFavouriteSubject(subj));
        dom.quickSuggestions.appendChild(span);
      });
    }

    highlightRelevantChips(dom.interestsContainer, suggestions.interests);
    highlightRelevantChips(dom.skillsContainer, suggestions.skills);
  });
}

function highlightRelevantChips(container, relevantList) {
  if (!container || !relevantList) return;
  const chips = container.querySelectorAll('.chip');
  chips.forEach(chip => {
    const val = chip.getAttribute('data-val');
    chip.style.borderColor = relevantList.includes(val) ? "var(--blue-400)" : "";
  });
}

// -----------------------------------------------------------------------------
// Interactive Multi-Select Chips
// -----------------------------------------------------------------------------
function setupChipSelection() {
  dom.interestsContainer.querySelectorAll('.chip').forEach(chip => {
    chip.addEventListener('click', () => {
      const val = chip.getAttribute('data-val');
      if (state.selectedInterests.has(val)) {
        state.selectedInterests.delete(val);
        chip.classList.remove('selected');
      } else {
        state.selectedInterests.add(val);
        chip.classList.add('selected');
      }
      updateChipCounters();
      hideFormAlert();
    });
  });

  dom.skillsContainer.querySelectorAll('.chip').forEach(chip => {
    chip.addEventListener('click', () => {
      const val = chip.getAttribute('data-val');
      if (state.selectedSkills.has(val)) {
        state.selectedSkills.delete(val);
        chip.classList.remove('selected');
      } else {
        state.selectedSkills.add(val);
        chip.classList.add('selected');
      }
      updateChipCounters();
      hideFormAlert();
    });
  });
}

function updateChipCounters() {
  const intCount = state.selectedInterests.size;
  dom.interestCount.textContent = `${intCount} selected`;
  dom.hiddenInterests.value = Array.from(state.selectedInterests).join(', ');

  const skCount = state.selectedSkills.size;
  dom.skillsCount.textContent = `${skCount} selected`;
  dom.hiddenSkills.value = Array.from(state.selectedSkills).join(', ');
}

function setupQuickSubjectBadges() {
  document.querySelectorAll('.suggest-badge').forEach(badge => {
    badge.addEventListener('click', () => {
      const subj = badge.getAttribute('data-subject');
      appendFavouriteSubject(subj);
    });
  });
}

function appendFavouriteSubject(subject) {
  const currentVal = dom.favouriteSubjects.value.trim();
  if (!currentVal) {
    dom.favouriteSubjects.value = subject;
  } else {
    const list = currentVal.split(',').map(s => s.trim().toLowerCase());
    if (!list.includes(subject.toLowerCase())) {
      dom.favouriteSubjects.value = `${currentVal}, ${subject}`;
    }
  }
  dom.favouriteSubjects.focus();
  hideFormAlert();
}

// =============================================================================
// 5. FORM VALIDATION & API SUBMISSION
// =============================================================================
function setupFormValidationAndSubmission() {
  dom.form.addEventListener('submit', async (e) => {
    e.preventDefault();
    hideFormAlert();

    const name = dom.studentName.value.trim();
    const degree = dom.degreeProgramme.value;
    const semester = dom.currentSemester.value;
    const careerGoal = dom.careerGoal.value;
    const favouriteSubjects = dom.favouriteSubjects.value.trim();
    const interests = Array.from(state.selectedInterests);
    const skills = Array.from(state.selectedSkills);

    // -------------------------------------------------------------------------
    // MANDATORY VALIDATIONS WITH UNDERSTANDABLE ERROR MESSAGES
    // -------------------------------------------------------------------------
    if (!name) {
      showFormAlert("Please enter your Student Full Name (e.g. Rohan Sharma).");
      dom.studentName.focus();
      return;
    }

    if (!degree) {
      showFormAlert("Please select your Degree Programme from the dropdown.");
      dom.degreeProgramme.focus();
      return;
    }

    if (!semester) {
      showFormAlert("Please select your Current Semester (1 to 8).");
      dom.currentSemester.focus();
      return;
    }

    if (interests.length === 0) {
      showFormAlert("Please select at least one Academic Interest from the chips below.");
      dom.interestsContainer.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }

    if (!careerGoal) {
      showFormAlert("Please select your Primary Career Goal.");
      dom.careerGoal.focus();
      return;
    }

    // Recommended supplementary fields
    if (skills.length === 0) {
      showFormAlert("Please select at least one Technical / Practical Skill.");
      dom.skillsContainer.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }

    if (!favouriteSubjects) {
      showFormAlert("Please enter or click at least one Favourite Subject.");
      dom.favouriteSubjects.focus();
      return;
    }

    // Build Student Profile Payload
    const studentProfile = {
      name,
      degree,
      semester: parseInt(semester, 10),
      careerGoal,
      interests,
      skills,
      favouriteSubjects
    };

    await handleRecommendationRequest(studentProfile);
  });

  // Reset Button
  dom.resetBtn.addEventListener('click', () => {
    dom.form.reset();
    state.selectedInterests.clear();
    state.selectedSkills.clear();
    dom.interestsContainer.querySelectorAll('.chip').forEach(c => c.classList.remove('selected'));
    dom.skillsContainer.querySelectorAll('.chip').forEach(c => c.classList.remove('selected'));
    updateChipCounters();

    dom.ayLabel.textContent = "Please select a semester";
    dom.ayBadge.textContent = "Not Selected";
    dom.academicYearDisplay.classList.remove('active');
    hideFormAlert();

    dom.resultsSection.style.display = 'none';
    dom.loadingSection.style.display = 'none';
    window.scrollTo({ top: dom.form.offsetTop - 80, behavior: 'smooth' });
  });
}

function showFormAlert(message) {
  dom.alertMessage.textContent = message;
  dom.formAlert.style.display = 'flex';
  dom.formAlert.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function hideFormAlert() {
  dom.formAlert.style.display = 'none';
}

// =============================================================================
// 6. CONNECT TO FLASK BACKEND: POST /api/recommend
// =============================================================================
async function handleRecommendationRequest(studentProfile) {
  // Show loading radar
  dom.loadingSection.style.display = 'block';
  dom.resultsSection.style.display = 'none';
  dom.loadingSection.scrollIntoView({ behavior: 'smooth', block: 'start' });

  // Button loading state
  const submitText = dom.submitBtn.querySelector('.btn-text');
  const submitLoader = dom.submitBtn.querySelector('.btn-loader');
  submitText.style.display = 'none';
  submitLoader.style.display = 'inline-flex';
  dom.submitBtn.disabled = true;

  try {
    // Run visual status steps
    const animationPromise = runSteppedLoadingAnimation();

    // Call Flask Backend API
    const apiPromise = fetch(API_CONFIG.endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify(studentProfile)
    });

    const [_, response] = await Promise.all([animationPromise, apiPromise]);

    if (!response.ok) {
      const errBody = await response.json().catch(() => ({}));
      const msg = errBody.error || errBody.message || `Server error: HTTP ${response.status}`;
      throw new Error(msg);
    }

    const data = await response.json();

    if (!data || !data.recommendations || data.recommendations.length === 0) {
      throw new Error("No recommendations returned for this profile from the backend.");
    }

    // Render results dynamically from backend data
    renderRecommendationResults(studentProfile, data.recommendations);

  } catch (error) {
    console.error("Backend Recommendation Error:", error);
    let msg = error.message;
    if (msg.includes("Failed to fetch") || msg.includes("NetworkError")) {
      msg = "Cannot connect to Flask server at http://127.0.0.1:5000. Please start the backend using 'python backend/app.py' or double-click 'run.bat'.";
    }
    showFormAlert(`⚠️ Backend Connection Error: ${msg}`);
    dom.form.scrollIntoView({ behavior: 'smooth', block: 'start' });
  } finally {
    dom.loadingSection.style.display = 'none';
    submitText.style.display = 'inline-flex';
    submitLoader.style.display = 'none';
    dom.submitBtn.disabled = false;
  }
}

// -----------------------------------------------------------------------------
// Visual Loading Steps
// -----------------------------------------------------------------------------
function runSteppedLoadingAnimation() {
  return new Promise(resolve => {
    const steps = [
      { text: "Connecting to Flask API & validating academic profile...", subtext: "Checking UGC Choice Based Credit System (CBCS) requirements", progress: 25, activeStep: 1 },
      { text: "Executing rule-based recommendation engine in Python...", subtext: "Filtering electives available for your degree & semester", progress: 55, activeStep: 2 },
      { text: "Calculating weighted match scores against SQLite database...", subtext: `Optimizing path towards '${dom.careerGoal.value}' roles`, progress: 85, activeStep: 3 },
      { text: "Finalizing top 3 elective recommendations...", subtext: "Rendering personalized rationale & course outcomes", progress: 100, activeStep: 4 }
    ];

    let currentStepIdx = 0;
    const interval = setInterval(() => {
      if (currentStepIdx < steps.length) {
        const step = steps[currentStepIdx];
        dom.loadingStatusText.textContent = step.text;
        dom.loadingSubtext.textContent = step.subtext;
        dom.loadingProgressBar.style.width = `${step.progress}%`;

        [dom.lStep1, dom.lStep2, dom.lStep3, dom.lStep4].forEach((el, idx) => {
          if (idx <= currentStepIdx) el.classList.add('active');
          else el.classList.remove('active');
        });

        currentStepIdx++;
      } else {
        clearInterval(interval);
        setTimeout(resolve, 200);
      }
    }, 250);
  });
}

// =============================================================================
// 7. DISPLAY DYNAMIC RECOMMENDATION RESULTS
// =============================================================================
function renderRecommendationResults(profile, recommendations) {
  dom.resStudentName.textContent = profile.name;
  dom.resDegree.textContent = profile.degree;
  dom.resSemester.textContent = `Semester ${profile.semester}`;

  let yrString = "";
  if (profile.semester <= 2) yrString = "1st Academic Year (Foundation)";
  else if (profile.semester <= 4) yrString = "2nd Academic Year (Core & Skill Enhancement)";
  else if (profile.semester <= 6) yrString = "3rd Academic Year (Discipline Electives)";
  else yrString = "4th Academic Year (Advanced & Research / Industry)";

  dom.resAcademicYear.textContent = yrString;
  dom.resCareerGoal.textContent = profile.careerGoal;

  // Clear previous cards
  dom.cardsContainer.innerHTML = "";

  // Render Top 3 Recommendation Cards
  recommendations.slice(0, 3).forEach((item, index) => {
    const card = createElectiveCardElement(item, index + 1);
    dom.cardsContainer.appendChild(card);
  });

  // Reveal results section & scroll
  dom.resultsSection.style.display = 'block';
  dom.resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });

  state.lastRecommendations = recommendations;
}

function createElectiveCardElement(elective, rank) {
  const card = document.createElement('div');
  card.className = `elective-card rank-${rank}`;

  // Elective Category Badge Class
  const category = elective.category || "Academic Elective (DSE)";
  let catClass = "badge-academic";
  if (category.includes("Open Elective")) catClass = "badge-open";
  else if (category.includes("Skill Enhancement")) catClass = "badge-skill";

  // Match Percentage Calculation
  const matchPct = elective.matchPercentage || elective.match_percentage || 85;

  // Skills List
  const skillsList = elective.skills_gained || elective.skills || [];
  const skillsHtml = skillsList.map(sk => `<span class="learned-skill-badge">${escapeHtml(sk)}</span>`).join('');

  // Course Title & Code
  const courseTitle = elective.title || elective.name || "Elective Subject";
  const courseCode = elective.code || `ELEC-${rank}01`;
  const courseCredits = elective.credits || "4 Credits";
  const courseDesc = elective.description || "Course description currently being updated under BoS guidelines.";
  const matchReason = elective.reason || elective.personalizedRationale || "Recommended based on your curriculum alignment and career goal.";

  card.innerHTML = `
    <div class="card-rank-accent"></div>
    <div class="card-header-area">
      <div class="card-top-row">
        <span class="badge ${catClass}">${escapeHtml(category)}</span>
        <div class="match-gauge ${matchPct >= 90 ? 'high' : ''}">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
          <span>${matchPct}% Match</span>
        </div>
      </div>
      <div class="subject-code-tag">${escapeHtml(courseCode)} &bull; ${escapeHtml(courseCredits)}</div>
      <h3 class="card-subject-title">${escapeHtml(courseTitle)}</h3>

      <!-- Match Percentage Progress Bar -->
      <div class="match-progress-container">
        <div class="match-progress-info">
          <span class="match-progress-text">Match Score: <strong>${matchPct}%</strong></span>
          <span class="match-progress-tag">${matchPct >= 90 ? 'Strong Match' : 'Good Match'}</span>
        </div>
        <div class="match-progress-track">
          <div class="match-progress-bar-fill" style="width: ${matchPct}%;"></div>
        </div>
      </div>
    </div>

    <div class="card-body-area">
      <p class="subject-description">${escapeHtml(courseDesc)}</p>

      <div class="recommendation-rationale-box">
        <div class="rationale-title">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
          <span>Why It Matches Your Interests &amp; Career</span>
        </div>
        <p class="rationale-text">${escapeHtml(matchReason)}</p>
      </div>

      <div class="skills-learned-section">
        <span class="skills-heading">Key Skills You Will Acquire:</span>
        <div class="skills-learned-list">
          ${skillsHtml}
        </div>
      </div>
    </div>

    <div class="card-footer-area">
      <span class="course-credit-info">UGC CBCS Scheme</span>
      <button class="btn btn-secondary btn-sm view-syllabus-btn">
        <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>
        <span>View Detailed Syllabus</span>
      </button>
    </div>
  `;

  // Attach Syllabus click listener
  const syllabusBtn = card.querySelector('.view-syllabus-btn');
  syllabusBtn.addEventListener('click', () => {
    openSyllabusModal(elective);
  });

  return card;
}

// =============================================================================
// 8. DETAILED SYLLABUS MODAL
// =============================================================================
function setupModalHandlers() {
  dom.closeModalBtn.addEventListener('click', closeSyllabusModal);
  dom.modalDoneBtn.addEventListener('click', closeSyllabusModal);

  dom.syllabusModal.addEventListener('click', (e) => {
    if (e.target === dom.syllabusModal) closeSyllabusModal();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && dom.syllabusModal.classList.contains('open')) {
      closeSyllabusModal();
    }
  });
}

function openSyllabusModal(elective) {
  const code = elective.code || "ELEC";
  const cat = elective.category || "Academic Elective (DSE)";
  const title = elective.title || elective.name || "Course Title";
  const credits = elective.credits || "4 Credits";

  dom.modalSubjectCode.textContent = `${code} • ${cat}`;
  dom.modalSubjectName.textContent = title;
  dom.modalCreditBadge.textContent = credits;

  const syl = elective.syllabus || {};
  const textbooks = syl.textbooks || [
    "University Board of Studies Prescribed Textbooks (Refer Department Library).",
    "UGC Model Curriculum Reference Works."
  ];

  const textbooksHtml = textbooks.map(tb => `<li>${escapeHtml(tb)}</li>`).join('');

  dom.modalBodyContent.innerHTML = `
    <div class="syllabus-unit">
      <h4 class="unit-title">${escapeHtml(syl.unit1 || "Unit 1: Foundational Principles & Core Concepts")}</h4>
    </div>
    <div class="syllabus-unit">
      <h4 class="unit-title">${escapeHtml(syl.unit2 || "Unit 2: Methodological Frameworks & Practical Implementation")}</h4>
    </div>
    <div class="syllabus-unit">
      <h4 class="unit-title">${escapeHtml(syl.unit3 || "Unit 3: Applied Industry Techniques & Case Studies")}</h4>
    </div>
    <div class="syllabus-unit">
      <h4 class="unit-title">${escapeHtml(syl.unit4 || "Unit 4: Advanced Topics & Systems Architecture")}</h4>
    </div>
    <div class="syllabus-unit">
      <h4 class="unit-title">${escapeHtml(syl.unit5 || "Unit 5: Production Deployment, Standards & Governance in India")}</h4>
    </div>

    <div class="syllabus-unit" style="margin-top: 1.5rem; background: var(--blue-50); padding: 1rem; border-radius: var(--radius-md);">
      <h4 class="unit-title" style="color: var(--blue-950);">Prescribed Textbooks &amp; Indian Reference Works:</h4>
      <ul class="textbook-list">
        ${textbooksHtml}
      </ul>
    </div>
  `;

  dom.syllabusModal.classList.add('open');
  dom.syllabusModal.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';
}

function closeSyllabusModal() {
  dom.syllabusModal.classList.remove('open');
  dom.syllabusModal.setAttribute('aria-hidden', 'true');
  document.body.style.overflow = '';
}

// -----------------------------------------------------------------------------
// Print / Save Advisory Slip
// -----------------------------------------------------------------------------
function setupPrintHandler() {
  if (dom.printBtn) {
    dom.printBtn.addEventListener('click', () => {
      window.print();
    });
  }
}

// -----------------------------------------------------------------------------
// Helper: HTML Escaper
// -----------------------------------------------------------------------------
function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
