"""
test_api.py - Unit test suite for Flask REST API endpoints and Frontend Serving
Tests:
- GET  / (Frontend HTML dashboard)
- GET  /style.css (Frontend CSS)
- GET  /script.js (Frontend JS)
- GET  /api/health
- GET  /api/electives
- GET  /api/electives?degree=BCA&semester=5
- POST /api/recommend (Valid input)
- POST /api/recommend (Invalid / Missing input)
"""
import sys
import os
import json

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app import app
from database import init_db

init_db()
client = app.test_client()

def test_frontend_serving():
    # Test index.html
    res_index = client.get('/')
    assert res_index.status_code == 200
    assert b"AcademicElective" in res_index.data or b"Academic Elective" in res_index.data
    print("[PASS] GET / (Serves index.html dashboard)")

    # Test style.css
    res_css = client.get('/style.css')
    assert res_css.status_code == 200
    print("[PASS] GET /style.css (Serves CSS stylesheet)")

    # Test script.js
    res_js = client.get('/script.js')
    assert res_js.status_code == 200
    print("[PASS] GET /script.js (Serves JavaScript client)")

def test_health():
    response = client.get('/api/health')
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data["status"] == "online"
    assert "total_electives_loaded" in data
    print("[PASS] GET /api/health")

def test_get_all_electives():
    response = client.get('/api/electives')
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data["status"] == "success"
    assert data["count"] >= 20
    print(f"[PASS] GET /api/electives (Returned {data['count']} electives)")

def test_get_filtered_electives():
    response = client.get('/api/electives?degree=BCA&semester=5')
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data["status"] == "success"
    for el in data["electives"]:
        assert "BCA" in el["degrees"]
        assert 5 in el["semesters"]
    print(f"[PASS] GET /api/electives?degree=BCA&semester=5 (Returned {data['count']} electives)")

def test_recommend_valid():
    payload = {
        "name": "Aditya Verma",
        "degree": "BCA",
        "semester": 5,
        "careerGoal": "Software Developer",
        "interests": ["Web Technologies", "Cloud Architecture"],
        "skills": ["Python", "JavaScript", "HTML / CSS / JavaScript"],
        "favouriteSubjects": "Database Management Systems, Software Engineering"
    }
    response = client.post('/api/recommend', json=payload)
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data["status"] == "success"
    assert len(data["recommendations"]) == 3
    print("[PASS] POST /api/recommend (Valid Payload)")
    for i, rec in enumerate(data["recommendations"], 1):
        print(f"       Top {i}: {rec['title']} ({rec['code']}) - Match: {rec['matchPercentage']}%")

def test_recommend_missing_field():
    payload = {
        "name": "Incomplete Student",
        "degree": "B.Tech"
        # Missing semester, careerGoal, etc.
    }
    response = client.post('/api/recommend', json=payload)
    assert response.status_code == 400
    data = json.loads(response.data)
    assert data["status"] == "fail"
    assert "details" in data
    print("[PASS] POST /api/recommend (Missing Fields 400 Validation)")

if __name__ == '__main__':
    print("\nRunning API Endpoint and Frontend Serving Tests...")
    test_frontend_serving()
    test_health()
    test_get_all_electives()
    test_get_filtered_electives()
    test_recommend_valid()
    test_recommend_missing_field()
    print("\nAll 8 tests completed successfully!\n")
