"""
recommender.py - Rule-Based Recommendation Engine for Academic Electives
Indian Higher Education System (NEP 2020 & CBCS Aligned)

This module implements:
1. Rule-based evaluation comparing student profile against eligible electives.
2. Degree programme gating: ONLY recommends subjects relevant to the student's selected degree.
3. Scoring based on:
   - Degree Programme (Strict Filter)
   - Semester Eligibility
   - Career Goals (Highest Weight)
   - Academic Interests
   - Technical Skills
   - Favourite Subjects
4. Ranking and returning the Top 3 matching electives with match percentages,
   descriptions, personalized rationales, and skills gained.
"""

from database import get_all_electives


def calculate_elective_score(student_profile, elective):
    """
    Compute a compatibility score for a single elective against the student profile.
    
    Weights:
    - Degree Programme: Pre-filtered (Mandatory prerequisite)
    - Semester: Up to 20 points
    - Career Goal Match: 35 points
    - Academic Interests Overlap: Up to 30 points
    - Technical Skills Overlap: Up to 24 points
    - Favourite Subjects Affinity: Up to 12 points
    """
    score = 45  # Baseline score for degree-eligible course

    degree = student_profile.get("degree", "").strip()
    semester = int(student_profile.get("semester", 1))
    career_goal = student_profile.get("careerGoal") or student_profile.get("career_goal", "")
    interests = student_profile.get("interests", [])
    skills = student_profile.get("skills", [])
    fav_subjects_raw = student_profile.get("favouriteSubjects") or student_profile.get("favourite_subjects", "")

    # Parse comma-separated favourite subjects
    fav_subjects = [s.strip().lower() for s in fav_subjects_raw.split(",") if s.strip()]

    # 1. Semester Eligibility Check
    # Colleges schedule electives in specific semesters under CBCS/NEP baskets
    elective_semesters = elective.get("semesters", [])
    if semester in elective_semesters:
        score += 20
    else:
        # Check if elective is within +-1 semester
        if any(abs(semester - s) <= 1 for s in elective_semesters):
            score += 10
        else:
            score -= 10

    # 2. Career Goal Alignment (Highest Priority)
    # Target roles (e.g. Software Developer, Data Scientist, Accountant, Govt Jobs)
    target_career_goals = elective.get("career_goals") or elective.get("careerGoals", [])
    if career_goal and career_goal in target_career_goals:
        score += 35

    # 3. Academic Interests Overlap
    # Compares user interests against elective title, stream, and description
    elective_text = f"{elective.get('title', '')} {elective.get('description', '')} {elective.get('stream', '')}".lower()
    interest_matches = 0
    for interest in interests:
        interest_lower = interest.lower()
        if interest_lower in elective_text:
            interest_matches += 1
            score += 10
        elif any(word in elective_text for word in interest_lower.split() if len(word) > 3):
            interest_matches += 1
            score += 6
        if interest_matches >= 3:
            break

    # 4. Technical Skills Overlap
    # Compares tools/languages the student knows with syllabus skills
    course_skills = [s.lower() for s in elective.get("skills", [])]
    skill_matches = 0
    for user_skill in skills:
        user_skill_lower = user_skill.lower()
        if any(user_skill_lower in cs or cs in user_skill_lower for cs in course_skills):
            skill_matches += 1
            score += 8
        if skill_matches >= 3:
            break

    # 5. Favourite Subjects Affinity
    # Bridges foundational subjects previously taken with this elective
    for fav in fav_subjects:
        if fav in elective_text:
            score += 12
            break

    # 6. Normalize Match Percentage (Realistic Indian College Grading 75% to 98%)
    match_percentage = min(98, max(75, int(score * 0.65)))

    return score, match_percentage, interest_matches, skill_matches


def build_recommendation_reason(student_profile, elective, match_percentage):
    """
    Formulate a personalized academic reason explaining why this elective
    was selected for the student.
    """
    degree = student_profile.get("degree", "your degree")
    semester = student_profile.get("semester", "")
    career_goal = student_profile.get("careerGoal") or student_profile.get("career_goal", "your career destination")
    interests = student_profile.get("interests", [])
    skills = student_profile.get("skills", [])
    fav_subjects = student_profile.get("favouriteSubjects") or student_profile.get("favourite_subjects", "")

    top_interests = " and ".join(interests[:2]) if interests else "academic domain"
    top_skills = ", ".join(skills[:2]) if skills else "technical competencies"

    reasons = [
        f"Directly accelerates your goal of becoming an {career_goal}.",
        f"Designed for Semester {semester} of {degree} under the UGC CBCS framework.",
        f"Builds on your interest in {top_interests} and reinforces your skills in {top_skills}."
    ]

    if fav_subjects:
        primary_fav = fav_subjects.split(",")[0].strip()
        reasons.append(f"Provides natural progression from your foundation in {primary_fav}.")

    return " ".join(reasons)


def recommend_electives(student_profile):
    """
    Main recommendation function.
    
    Accepts student profile dictionary:
    {
        "name": "Rohan Sharma",
        "degree": "BCA",
        "semester": 5,
        "careerGoal": "Software Developer",
        "interests": ["Web Technologies", "Cloud Architecture"],
        "skills": ["Python", "JavaScript", "SQL"],
        "favouriteSubjects": "Database Management Systems, Computer Networks"
    }
    
    Returns a list of the Top 3 recommended electives.
    """
    selected_degree = student_profile.get("degree", "").strip()

    # Load all configurable electives from SQLite database
    all_electives = get_all_electives()

    # --------------------------------------------------------------------------
    # CRITICAL RULE: Filter ONLY electives eligible for student's degree
    # --------------------------------------------------------------------------
    eligible_electives = []
    for elective in all_electives:
        elective_degrees = elective.get("degrees", [])
        if selected_degree in elective_degrees:
            eligible_electives.append(elective)

    # If no degree-specific electives found (fallback guard)
    if not eligible_electives:
        eligible_electives = all_electives

    # Score each eligible elective
    scored_candidates = []
    for elective in eligible_electives:
        score, match_pct, _, _ = calculate_elective_score(student_profile, elective)
        reason = build_recommendation_reason(student_profile, elective, match_pct)

        candidate = {
            "id": elective.get("code") or elective.get("id"),
            "code": elective.get("code"),
            "title": elective.get("title"),
            "name": elective.get("name") or elective.get("title"),
            "stream": elective.get("stream", "General"),
            "category": elective.get("category", "Academic Elective (DSE)"),
            "credits": elective.get("credits", "4 Credits"),
            "description": elective.get("description", ""),
            "matchPercentage": match_pct,
            "match_percentage": match_pct,
            "reason": reason,
            "personalizedRationale": reason,  # Compatibility with existing frontend
            "skills": elective.get("skills", []),
            "skills_gained": elective.get("skills", []),
            "syllabus": elective.get("syllabus", {}),
            "_internal_score": score
        }
        scored_candidates.append(candidate)

    # Sort descending by calculated score
    scored_candidates.sort(key=lambda x: x["_internal_score"], reverse=True)

    # Extract top 3 distinct electives
    top_three = []
    seen_codes = set()
    for item in scored_candidates:
        if len(top_three) >= 3:
            break
        if item["code"] not in seen_codes:
            seen_codes.add(item["code"])
            # Remove internal scoring field before returning
            del item["_internal_score"]
            top_three.push if hasattr(top_three, 'push') else top_three.append(item)

    # Refine match percentages for clear hierarchy among top 3
    if len(top_three) >= 3:
        top_three[0]["matchPercentage"] = max(94, top_three[0]["matchPercentage"])
        top_three[0]["match_percentage"] = top_three[0]["matchPercentage"]

        top_three[1]["matchPercentage"] = min(top_three[0]["matchPercentage"] - 3, max(89, top_three[1]["matchPercentage"]))
        top_three[1]["match_percentage"] = top_three[1]["matchPercentage"]

        top_three[2]["matchPercentage"] = min(top_three[1]["matchPercentage"] - 3, max(84, top_three[2]["matchPercentage"]))
        top_three[2]["match_percentage"] = top_three[2]["matchPercentage"]

    return top_three

