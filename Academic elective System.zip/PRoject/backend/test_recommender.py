"""
test_recommender.py - Quick verification script for backend database and recommendation engine
"""
import sys
import os

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from database import init_db, get_all_electives
from recommender import recommend_electives

# Initialize DB
init_db()

print("\n--- TEST 1: B.Tech, Sem 5, AI Engineer ---")
p1 = {
    "name": "Rohan Sharma",
    "degree": "B.Tech",
    "semester": 5,
    "careerGoal": "AI Engineer",
    "interests": ["Artificial Intelligence", "Data Analytics"],
    "skills": ["Python", "Machine Learning"],
    "favouriteSubjects": "Data Structures, Database Management Systems"
}
recs1 = recommend_electives(p1)
for i, r in enumerate(recs1, 1):
    print(f"Top {i}: {r['title']} ({r['code']}) - Match: {r['matchPercentage']}% - Category: {r['category']}")
    print(f"       Skills: {', '.join(r['skills'][:3])}")
    print(f"       Reason: {r['reason']}")

print("\n--- TEST 2: B.Com, Sem 4, Accountant ---")
p2 = {
    "name": "Pooja Patel",
    "degree": "B.Com",
    "semester": 4,
    "careerGoal": "Accountant",
    "interests": ["Financial Accounting", "Corporate Finance"],
    "skills": ["Tally Prime & GST", "Advanced Excel"],
    "favouriteSubjects": "Financial Accounting, Corporate Accounting"
}
recs2 = recommend_electives(p2)
for i, r in enumerate(recs2, 1):
    print(f"Top {i}: {r['title']} ({r['code']}) - Match: {r['matchPercentage']}% - Category: {r['category']}")
    print(f"       Reason: {r['reason']}")

print("\n--- TEST 3: B.A., Sem 5, Government Jobs ---")
p3 = {
    "name": "Vikram Singh",
    "degree": "B.A.",
    "semester": 5,
    "careerGoal": "Government Jobs",
    "interests": ["Indian Polity & Governance", "Public Administration"],
    "skills": ["Business Communication"],
    "favouriteSubjects": "Indian Government and Politics, Public Policy"
}
recs3 = recommend_electives(p3)
for i, r in enumerate(recs3, 1):
    print(f"Top {i}: {r['title']} ({r['code']}) - Match: {r['matchPercentage']}% - Category: {r['category']}")
    print(f"       Reason: {r['reason']}")

print("\nAll recommendation tests executed successfully!")

