"""
database.py - SQLite Database Management for Academic Elective Recommendation System
Indian Higher Education System (NEP 2020 & CBCS Aligned)

This module handles:
1. Creating the SQLite database and 'electives' table.
2. Automatically seeding realistic sample electives across Computer Science, Commerce,
   Business, and Arts streams when the app runs for the first time.
3. Providing helper query functions to fetch and filter electives.
"""

import os
import sqlite3
import json

# Path to the SQLite database file in the backend directory
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE_PATH = os.path.join(BASE_DIR, "electives.db")


def get_db_connection():
    """
    Establish and return a connection to the SQLite database.
    Configures row_factory as sqlite3.Row for dictionary-like column access.
    """
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn


# ==============================================================================
# SAMPLE ELECTIVES DATASET (INDIAN UNDERGRADUATE COLLEGE RELEVANT)
# ==============================================================================
# Supports: BCA, B.Sc Computer Science, B.Com, BBA, B.A., and B.Tech across Semesters 1-8.
SAMPLE_ELECTIVES = [
    # --------------------------------------------------------------------------
    # COMPUTER SCIENCE & IT STREAM
    # (B.Tech, BCA, B.Sc Computer Science)
    # --------------------------------------------------------------------------
    {
        "code": "BCSE-501",
        "title": "Artificial Intelligence",
        "name": "Artificial Intelligence",
        "stream": "Computer Science",
        "category": "Academic Elective (DSE)",
        "credits": "4 Credits (Theory: 3, Lab: 1)",
        "degrees": ["B.Tech", "BCA", "B.Sc Computer Science"],
        "semesters": [5, 6, 7, 8],
        "career_goals": ["AI Engineer", "Data Scientist", "Software Developer", "Higher Studies"],
        "skills": ["State Space Search", "Heuristic Algorithms", "Knowledge Representation", "Prolog / Python AI", "Adversarial Search"],
        "description": "Comprehensive introduction to artificial intelligence principles, problem-solving through heuristic search, logic agents, game trees, and automated reasoning.",
        "syllabus": {
            "unit1": "Unit 1: Foundations of Artificial Intelligence & Problem Formulation",
            "unit2": "Unit 2: Informed and Uninformed Search Strategies (A*, IDA*, Hill Climbing)",
            "unit3": "Unit 3: Knowledge Representation, First-Order Logic and Semantic Nets",
            "unit4": "Unit 4: Planning and Reasoning Under Uncertainty (Bayesian Networks)",
            "unit5": "Unit 5: Introduction to Expert Systems & Ethical AI in Indian Industry",
            "textbooks": [
                "Stuart Russell & Peter Norvig, 'Artificial Intelligence: A Modern Approach', Pearson India.",
                "Elaine Rich & Kevin Knight, 'Artificial Intelligence', McGraw Hill India.",
                "Deepak Khemani, 'A First Course in Artificial Intelligence', McGraw Hill Education India."
            ]
        }
    },
    {
        "code": "BCSE-502",
        "title": "Machine Learning",
        "name": "Machine Learning",
        "stream": "Computer Science",
        "category": "Academic Elective (DSE)",
        "credits": "4 Credits (Theory: 3, Lab: 1)",
        "degrees": ["B.Tech", "BCA", "B.Sc Computer Science"],
        "semesters": [5, 6, 7, 8],
        "career_goals": ["AI Engineer", "Data Scientist", "Software Developer", "Higher Studies"],
        "skills": ["Supervised Learning", "Scikit-Learn", "Feature Engineering", "Neural Networks", "Model Validation"],
        "description": "In-depth exposure to statistical machine learning algorithms, model training, cross-validation, and production inference using Python and real-world datasets.",
        "syllabus": {
            "unit1": "Unit 1: Introduction to Machine Learning & Mathematical Foundations",
            "unit2": "Unit 2: Supervised Learning (Linear & Logistic Regression, Decision Trees, Random Forests)",
            "unit3": "Unit 3: Unsupervised Learning (K-Means, PCA, Dimensionality Reduction)",
            "unit4": "Unit 4: Deep Learning Foundations (Perceptrons, Feedforward Networks, PyTorch basics)",
            "unit5": "Unit 5: Real-world Model Deployment & Ethics in Indian Enterprises",
            "textbooks": [
                "Tom M. Mitchell, 'Machine Learning', McGraw Hill Education (India).",
                "Aurelien Geron, 'Hands-On Machine Learning with Scikit-Learn and TensorFlow', O'Reilly / Shroff Publishers India.",
                "Ethem Alpaydin, 'Introduction to Machine Learning', PHI Learning New Delhi."
            ]
        }
    },
    {
        "code": "BCSE-503",
        "title": "Data Science",
        "name": "Data Science",
        "stream": "Computer Science",
        "category": "Academic Elective (DSE)",
        "credits": "4 Credits (Theory: 3, Lab: 1)",
        "degrees": ["B.Tech", "BCA", "B.Sc Computer Science", "B.Com", "BBA"],
        "semesters": [4, 5, 6, 7, 8],
        "career_goals": ["Data Scientist", "Business Analyst", "Higher Studies"],
        "skills": ["Pandas & NumPy", "Data Cleaning & Wrangling", "Exploratory Data Analysis (EDA)", "Data Visualization", "Hypothesis Testing"],
        "description": "Focuses on the data science lifecycle: collecting, wrangling, visualizing, and extracting actionable insights from large structured and unstructured datasets.",
        "syllabus": {
            "unit1": "Unit 1: Data Science Lifecycle and Research Methodology",
            "unit2": "Unit 2: Data Wrangling with Python Pandas and NumPy",
            "unit3": "Unit 3: Exploratory Data Analysis and Statistical Summaries",
            "unit4": "Unit 4: Visual Storytelling with Matplotlib, Seaborn, and Plotly",
            "unit5": "Unit 5: Case Studies in Indian FinTech and E-Commerce Analytics",
            "textbooks": [
                "Joel Grus, 'Data Science from Scratch', O'Reilly / Shroff Publishers India.",
                "Jake VanderPlas, 'Python Data Science Handbook', O'Reilly India.",
                "V.K. Jain, 'Data Science & Machine Learning', Khanna Publishing New Delhi."
            ]
        }
    },
    {
        "code": "BCSE-504",
        "title": "Cyber Security",
        "name": "Cyber Security",
        "stream": "Computer Science",
        "category": "Academic Elective (DSE)",
        "credits": "4 Credits (Theory: 3, Lab: 1)",
        "degrees": ["B.Tech", "BCA", "B.Sc Computer Science"],
        "semesters": [5, 6, 7, 8],
        "career_goals": ["Cyber Security Analyst", "Software Developer", "Government Jobs"],
        "skills": ["Vulnerability Assessment", "Wireshark Packet Analysis", "Penetration Testing", "OWASP Top 10", "Network Forensics"],
        "description": "Comprehensive study of cyber attack vectors, defensive mitigation, cryptographic ciphers, port scanning, and securing corporate Indian IT infrastructures.",
        "syllabus": {
            "unit1": "Unit 1: Information Security Core Principles & Indian IT Act 2000/2008",
            "unit2": "Unit 2: Network Reconnaissance, Scanning & Wireshark Packet Analysis",
            "unit3": "Unit 3: Web Application Vulnerabilities & OWASP Top 10 Mitigation",
            "unit4": "Unit 4: Cryptographic Protocols, SSL/TLS, and Digital Signatures",
            "unit5": "Unit 5: Incident Response, Computer Forensics and Indian CERT-In Guidelines",
            "textbooks": [
                "William Stallings, 'Cryptography and Network Security', Pearson Education India.",
                "Stuart McClure, Joel Scambray, George Kurtz, 'Hacking Exposed', McGraw-Hill India.",
                "Pavan Duggal, 'Cyber Law - An Exhaustive Commentary', Universal Law Publishing New Delhi."
            ]
        }
    },
    {
        "code": "SEC-301",
        "title": "Web Development",
        "name": "Web Development",
        "stream": "Computer Science",
        "category": "Skill Enhancement Course (SEC)",
        "credits": "3 Credits (Theory: 1, Lab: 2)",
        "degrees": ["BCA", "B.Sc Computer Science", "B.Tech", "BBA", "B.Com", "B.A."],
        "semesters": [3, 4, 5, 6, 7, 8],
        "career_goals": ["Software Developer", "Entrepreneur", "Business Analyst"],
        "skills": ["HTML5 & CSS3", "JavaScript (ES6+)", "Responsive UI Design", "REST API Consumption", "Node.js Basics"],
        "description": "Practical, laboratory-intensive course teaching modern responsive website development, interactive user interfaces, and full-stack web applications.",
        "syllabus": {
            "unit1": "Unit 1: Semantic HTML5, CSS3 Flexbox & Grid Layouts",
            "unit2": "Unit 2: Modern JavaScript (DOM Manipulation, Events, Async/Await)",
            "unit3": "Unit 3: Responsive Web Design & CSS Frameworks",
            "unit4": "Unit 4: Backend Integration & REST API Consumption",
            "unit5": "Unit 5: Project Version Control with Git & Web Hosting",
            "textbooks": [
                "Jon Duckett, 'HTML & CSS: Design and Build Websites', Wiley India.",
                "David Flanagan, 'JavaScript: The Definitive Guide', O'Reilly / Shroff Publishers.",
                "Robin Wieruch, 'The Road to React', Self-published."
            ]
        }
    },
    {
        "code": "BCSE-601",
        "title": "Cloud Computing",
        "name": "Cloud Computing",
        "stream": "Computer Science",
        "category": "Academic Elective (DSE)",
        "credits": "4 Credits (Theory: 3, Lab: 1)",
        "degrees": ["B.Tech", "BCA", "B.Sc Computer Science"],
        "semesters": [5, 6, 7, 8],
        "career_goals": ["Software Developer", "Cyber Security Analyst", "Higher Studies"],
        "skills": ["AWS & Azure Architecture", "Docker Containers", "Kubernetes Orchestration", "Microservices", "CI/CD Pipelines"],
        "description": "Explores virtualization primitives, cloud delivery models (IaaS, PaaS, SaaS), distributed consensus, and deployment of resilient microservices.",
        "syllabus": {
            "unit1": "Unit 1: Distributed Systems Fundamentals and Cloud Evolution",
            "unit2": "Unit 2: Cloud Computing Architecture, Hypervisors, and Virtualization",
            "unit3": "Unit 3: Containerization with Docker & Kubernetes Orchestration",
            "unit4": "Unit 4: Serverless Computing & Microservices Architecture",
            "unit5": "Unit 5: Cloud Security, IAM Roles, and SRE Monitoring",
            "textbooks": [
                "Rajkumar Buyya, Christian Vecchiola, S. Thamarai Selvi, 'Mastering Cloud Computing', McGraw Hill India.",
                "Andrew S. Tanenbaum, Maarten van Steen, 'Distributed Systems', Pearson Education India.",
                "K. Hwang, G. Fox, J. Dongarra, 'Distributed and Cloud Computing', Morgan Kaufmann India."
            ]
        }
    },
    {
        "code": "SEC-201",
        "title": "Python Programming",
        "name": "Python Programming",
        "stream": "Computer Science",
        "category": "Skill Enhancement Course (SEC)",
        "credits": "3 Credits (Theory: 1, Lab: 2)",
        "degrees": ["BCA", "B.Sc Computer Science", "B.Tech", "B.Com", "BBA", "B.A."],
        "semesters": [1, 2, 3, 4, 5, 6, 7, 8],
        "career_goals": ["Software Developer", "Data Scientist", "AI Engineer", "Business Analyst"],
        "skills": ["Core Python Syntax", "Object-Oriented Programming", "File I/O & Exception Handling", "Scripting & Automation", "Third-party Libraries"],
        "description": "Foundational course covering object-oriented programming in Python, data structures, automated scripting, file handling, and introductory package development.",
        "syllabus": {
            "unit1": "Unit 1: Python Basics, Data Types, Control Flow, and Loops",
            "unit2": "Unit 2: Functions, Modules, and Exception Handling",
            "unit3": "Unit 3: Object-Oriented Programming (Classes, Inheritance, Polymorphism)",
            "unit4": "Unit 4: File I/O, Regular Expressions, and String Processing",
            "unit5": "Unit 5: Automation Scripting and Introduction to Virtual Environments",
            "textbooks": [
                "Reema Thareja, 'Python Programming Using Problem Solving Approach', Oxford University Press India.",
                "Allen B. Downey, 'Think Python', O'Reilly / Shroff Publishers.",
                "Mark Lutz, 'Learning Python', O'Reilly India."
            ]
        }
    },
    {
        "code": "BCSE-401",
        "title": "Database Management Systems",
        "name": "Database Management Systems",
        "stream": "Computer Science",
        "category": "Academic Elective (DSE)",
        "credits": "4 Credits (Theory: 3, Lab: 1)",
        "degrees": ["BCA", "B.Sc Computer Science", "B.Tech"],
        "semesters": [3, 4, 5, 6, 7, 8],
        "career_goals": ["Software Developer", "Data Scientist", "Business Analyst"],
        "skills": ["Relational Algebra", "SQL Query Optimization", "Database Normalization (1NF to BCNF)", "ACID Transactions", "Indexing & Joins"],
        "description": "Core course covering database schema design, entity-relationship modeling, relational algebra, SQL optimization, transactions, and concurrency control.",
        "syllabus": {
            "unit1": "Unit 1: DBMS Architecture, 3-Tier Model, and ER Modeling",
            "unit2": "Unit 2: Relational Model, Relational Algebra, and Calculus",
            "unit3": "Unit 3: Advanced SQL, Triggers, Views, and Stored Procedures",
            "unit4": "Unit 4: Relational Database Normalization (1NF, 2NF, 3NF, BCNF)",
            "unit5": "Unit 5: Transaction Management, Concurrency Control, and Recovery",
            "textbooks": [
                "Abraham Silberschatz, Henry F. Korth, S. Sudarshan, 'Database System Concepts', McGraw Hill India.",
                "Ramez Elmasri, Shamkant B. Navathe, 'Fundamentals of Database Systems', Pearson India.",
                "Raghu Ramakrishnan, Johannes Gehrke, 'Database Management Systems', McGraw Hill India."
            ]
        }
    },
    {
        "code": "BCSE-602",
        "title": "Mobile Application Development",
        "name": "Mobile Application Development",
        "stream": "Computer Science",
        "category": "Academic Elective (DSE)",
        "credits": "4 Credits (Theory: 2, Lab: 2)",
        "degrees": ["BCA", "B.Sc Computer Science", "B.Tech"],
        "semesters": [5, 6, 7, 8],
        "career_goals": ["Software Developer", "Entrepreneur"],
        "skills": ["Android SDK & Kotlin/Java", "Cross-Platform Frameworks", "Mobile UI/UX Design", "SQLite for Mobile", "Google Play Deployment"],
        "description": "Hands-on engineering of native and cross-platform mobile apps, screen lifecycles, background services, sensor access, and local data persistence.",
        "syllabus": {
            "unit1": "Unit 1: Mobile Ecosystem, Android Architecture, and Project Structure",
            "unit2": "Unit 2: Activities, Fragments, Intents, and User Interface Layouts",
            "unit3": "Unit 3: Mobile Data Storage (SharedPreferences, Room DB, SQLite)",
            "unit4": "Unit 4: Asynchronous Tasks, REST API Integration, and Push Notifications",
            "unit5": "Unit 5: App Monetization, Testing, and Google Play Store Publishing",
            "textbooks": [
                "Bill Phillips, Chris Stewart, Kristin Marsicano, 'Android Programming: The Big Nerd Ranch Guide'.",
                "Reto Meier, 'Professional Android Application Development', Wiley India.",
                "Pradeep Kothari, 'Android Application Development Black Book', Dreamtech Press India."
            ]
        }
    },

    # --------------------------------------------------------------------------
    # COMMERCE STREAM
    # (B.Com, BBA)
    # --------------------------------------------------------------------------
    {
        "code": "BCOM-301",
        "title": "Financial Accounting",
        "name": "Financial Accounting",
        "stream": "Commerce",
        "category": "Academic Elective (DSE)",
        "credits": "4 Credits (Theory: 4)",
        "degrees": ["B.Com", "BBA"],
        "semesters": [1, 2, 3, 4],
        "career_goals": ["Accountant", "Business Analyst", "Government Jobs"],
        "skills": ["Double-Entry Bookkeeping", "Trial Balance Preparation", "Balance Sheet Finalization", "Depreciation Accounting", "Indian AS Standards"],
        "description": "Fundamental principles of corporate accounting, journal entries, ledger posting, trial balance, depreciation accounting, and preparation of final financial statements.",
        "syllabus": {
            "unit1": "Unit 1: Conceptual Framework of Accounting & Indian Accounting Standards (Ind AS)",
            "unit2": "Unit 2: Journal, Ledger Posting, and Trial Balance Preparation",
            "unit3": "Unit 3: Depreciation Accounting (Straight Line & Written Down Value Methods)",
            "unit4": "Unit 4: Preparation of Financial Statements of Sole Proprietorship & Firms",
            "unit5": "Unit 5: Accounting for Special Transactions (Consignment and Joint Ventures)",
            "textbooks": [
                "P.C. Tulsian & Bharat Tulsian, 'Financial Accounting', S. Chand & Company New Delhi.",
                "J.R. Monga, 'Financial Accounting: Concepts and Applications', Mayur Paperbacks.",
                "M.C. Shukla, T.S. Grewal, S.C. Gupta, 'Advanced Accounts', S. Chand New Delhi."
            ]
        }
    },
    {
        "code": "BCOM-501",
        "title": "GST and Taxation",
        "name": "GST and Taxation",
        "stream": "Commerce",
        "category": "Academic Elective (DSE)",
        "credits": "4 Credits (Theory: 4)",
        "degrees": ["B.Com", "BBA"],
        "semesters": [3, 4, 5, 6],
        "career_goals": ["Accountant", "Business Analyst", "Entrepreneur", "Government Jobs"],
        "skills": ["GST Return Filing (GSTR-1, 3B)", "Corporate Income Tax", "TDS/TCS Computations", "Input Tax Credit (ITC)", "Tally Prime ERP"],
        "description": "Extensive study of direct and indirect taxation frameworks in India, with hands-on computer lab training in corporate tax computations and GST portal compliance.",
        "syllabus": {
            "unit1": "Unit 1: Indian Corporate Taxation Overview & Tax Planning Principles",
            "unit2": "Unit 2: Assessment of Corporate Entities and Profits & Gains from Business",
            "unit3": "Unit 3: Indian GST Framework (CGST, SGST, IGST Mechanisms, Supply Rules)",
            "unit4": "Unit 4: GST Compliance, E-Way Bills, and Input Tax Credit Reconciliation",
            "unit5": "Unit 5: TDS/TCS Rates, Advance Tax Payments, and Appeals under IT Act 1961",
            "textbooks": [
                "Dr. V.K. Singhania & Dr. Monica Singhania, 'Corporate Tax Planning', Taxmann Publications.",
                "Dr. Girish Ahuja & Dr. Ravi Gupta, 'Direct Taxes Law & Practice', Wolters Kluwer India.",
                "V.S. Datey, 'GST Ready Reckoner', Taxmann Publications New Delhi."
            ]
        }
    },
    {
        "code": "BCOM-402",
        "title": "Banking and Insurance",
        "name": "Banking and Insurance",
        "stream": "Commerce",
        "category": "Academic Elective (DSE)",
        "credits": "4 Credits (Theory: 4)",
        "degrees": ["B.Com", "BBA", "B.A."],
        "semesters": [3, 4, 5, 6],
        "career_goals": ["Accountant", "Business Analyst", "Government Jobs"],
        "skills": ["RBI Monetary Regulations", "Lending & Credit Appraisal", "NPA Management", "Life & General Insurance", "IRDAI Regulations"],
        "description": "Operational dynamics of Indian commercial banking, Reserve Bank of India monetary regulations, digital payments (UPI/NEFT), and life & general insurance contracts.",
        "syllabus": {
            "unit1": "Unit 1: Structure and Evolution of the Indian Banking System & RBI Role",
            "unit2": "Unit 2: Commercial Bank Operations, Credit Creation, and NPA Recovery",
            "unit3": "Unit 3: Digital Banking Innovations (UPI, IMPS, RTGS, Central Bank Digital Currency)",
            "unit4": "Unit 4: Principles of Insurance, Risk Assessment, and Life Insurance Policies",
            "unit5": "Unit 5: General Insurance (Fire, Marine, Health) and IRDAI Regulatory Framework",
            "textbooks": [
                "M.N. Mishra & S.B. Mishra, 'Insurance Principles and Practice', S. Chand & Company.",
                "O.P. Agarwal, 'Banking and Insurance', Himalaya Publishing House.",
                "S.K. Garg, 'Banking Law and Practice', Deep & Deep Publications New Delhi."
            ]
        }
    },
    {
        "code": "BCOM-502",
        "title": "Financial Management",
        "name": "Financial Management",
        "stream": "Commerce",
        "category": "Academic Elective (DSE)",
        "credits": "4 Credits (Theory: 4)",
        "degrees": ["B.Com", "BBA", "B.Tech"],
        "semesters": [3, 4, 5, 6, 7, 8],
        "career_goals": ["Accountant", "Business Analyst", "Entrepreneur", "Higher Studies"],
        "skills": ["Capital Budgeting (NPV, IRR)", "Working Capital Management", "Cost of Capital (WACC)", "Dividend Policies", "Leverage Analysis"],
        "description": "Teaches corporate financial decision making: capital budgeting techniques (NPV, IRR), capital structure theories, working capital optimization, and dividend strategies.",
        "syllabus": {
            "unit1": "Unit 1: Financial Management Objectives, Scope, and Time Value of Money",
            "unit2": "Unit 2: Capital Budgeting Decisions (Payback, ARR, NPV, IRR, PI)",
            "unit3": "Unit 3: Cost of Capital (Specific and Weighted Average Cost of Capital - WACC)",
            "unit4": "Unit 4: Capital Structure Theories (NI, NOI, Traditional, and MM Hypothesis)",
            "unit5": "Unit 5: Working Capital Management (Cash, Receivables, and Inventory Management)",
            "textbooks": [
                "Prasanna Chandra, 'Financial Management: Theory and Practice', McGraw Hill India.",
                "I.M. Pandey, 'Financial Management', Vikas Publishing House New Delhi.",
                "M.Y. Khan & P.K. Jain, 'Financial Management', McGraw Hill Education India."
            ]
        }
    },
    {
        "code": "BCOM-403",
        "title": "E-Commerce",
        "name": "E-Commerce",
        "stream": "Commerce",
        "category": "Open Elective (GE)",
        "credits": "3 Credits (Theory: 3)",
        "degrees": ["B.Com", "BBA", "BCA", "B.A."],
        "semesters": [3, 4, 5, 6, 7, 8],
        "career_goals": ["Entrepreneur", "Business Analyst", "Software Developer"],
        "skills": ["E-Commerce Business Models", "Payment Gateway Integration", "Digital Supply Chain", "Consumer Protection in E-Commerce", "E-Marketing"],
        "description": "Explores online business models (B2B, B2C, D2C), payment gateways, logistics fulfillment, cybersecurity compliances, and consumer protection in Indian e-commerce.",
        "syllabus": {
            "unit1": "Unit 1: Introduction to E-Commerce Architecture and Business Models",
            "unit2": "Unit 2: Electronic Payment Systems, Gateways, and Security Protocols",
            "unit3": "Unit 3: Supply Chain Fulfillment, Logistics, and Inventory Management",
            "unit4": "Unit 4: Legal & Regulatory Compliances under Indian Consumer Protection Act 2019",
            "unit5": "Unit 5: E-Commerce Analytics, Conversion Optimization, and Mobile Commerce",
            "textbooks": [
                "P.T. Joseph, 'E-Commerce: An Indian Perspective', PHI Learning New Delhi.",
                "Kenneth C. Laudon & Carol Guercio Traver, 'E-Commerce: Business, Technology, Society', Pearson India.",
                "Kamlesh K. Bajaj & Debjani Nag, 'E-Commerce: The Cutting Edge of Business', McGraw Hill."
            ]
        }
    },
    {
        "code": "BCOM-504",
        "title": "Business Analytics",
        "name": "Business Analytics",
        "stream": "Commerce",
        "category": "Academic Elective (DSE)",
        "credits": "4 Credits (Theory: 3, Lab: 1)",
        "degrees": ["B.Com", "BBA", "BCA", "B.Tech"],
        "semesters": [4, 5, 6, 7, 8],
        "career_goals": ["Business Analyst", "Data Scientist", "Higher Studies"],
        "skills": ["Descriptive & Predictive Analytics", "Advanced Excel Modeling", "Power BI / Tableau Dashboards", "Regression Modeling", "Executive Decision Making"],
        "description": "Data-driven business analysis: translating organizational datasets into managerial dashboards, forecasting sales, trend analysis, and performance modeling.",
        "syllabus": {
            "unit1": "Unit 1: Introduction to Business Analytics and Decision Modeling",
            "unit2": "Unit 2: Descriptive Analytics, Data Summarization, and Dashboarding",
            "unit3": "Unit 3: Predictive Modeling (Linear Regression, Time Series Forecasting)",
            "unit4": "Unit 4: Prescriptive Analytics, Optimization, and Simulation with Excel",
            "unit5": "Unit 5: Business Intelligence Case Studies in Indian Retail and Banking",
            "textbooks": [
                "U. Dinesh Kumar, 'Business Analytics: The Science of Data-Driven Decision Making', Wiley India.",
                "James R. Evans, 'Business Analytics', Pearson Education India.",
                "S. Christian Albright & Wayne L. Winston, 'Business Analytics: Data Analysis & Decision Making', Cengage India."
            ]
        }
    },

    # --------------------------------------------------------------------------
    # BUSINESS ADMINISTRATION STREAM
    # (BBA, B.Com)
    # --------------------------------------------------------------------------
    {
        "code": "BBA-301",
        "title": "Marketing Management",
        "name": "Marketing Management",
        "stream": "Business",
        "category": "Academic Elective (DSE)",
        "credits": "4 Credits (Theory: 4)",
        "degrees": ["BBA", "B.Com"],
        "semesters": [2, 3, 4, 5, 6],
        "career_goals": ["Entrepreneur", "Business Analyst", "Higher Studies"],
        "skills": ["Market Segmentation (STP)", "Marketing Mix (4Ps & 7Ps)", "Consumer Behavior Analysis", "Brand Positioning", "Competitive Strategy"],
        "description": "Covers core marketing principles: market segmentation, targeting, brand positioning, product lifecycle management, pricing strategies, and promotional campaigns.",
        "syllabus": {
            "unit1": "Unit 1: Marketing Concepts, Evolution, and Modern Marketing Environment",
            "unit2": "Unit 2: Consumer Buying Decision Process & Segmentation, Targeting, Positioning (STP)",
            "unit3": "Unit 3: Product Strategy, Product Life Cycle, and Brand Management",
            "unit4": "Unit 4: Pricing Strategies and Distribution Channel Decisions in India",
            "unit5": "Unit 5: Integrated Marketing Communications (IMC) and Rural Marketing Insights",
            "textbooks": [
                "Philip Kotler, Kevin Lane Keller, Abraham Koshy, Mithileshwar Jha, 'Marketing Management: A South Asian Perspective', Pearson India.",
                "Rajan Saxena, 'Marketing Management', McGraw Hill India.",
                "V.S. Ramaswamy & S. Namakumari, 'Marketing Management: Indian Context', Sage Publications."
            ]
        }
    },
    {
        "code": "BBA-401",
        "title": "Human Resource Management",
        "name": "Human Resource Management",
        "stream": "Business",
        "category": "Academic Elective (DSE)",
        "credits": "4 Credits (Theory: 4)",
        "degrees": ["BBA", "B.Com", "B.A."],
        "semesters": [3, 4, 5, 6],
        "career_goals": ["Business Analyst", "Entrepreneur", "Government Jobs"],
        "skills": ["Talent Acquisition & Recruitment", "Performance Appraisal Systems", "Indian Labor Laws & Codes", "Training & Development", "Employee Grievance Handling"],
        "description": "Strategic human resource practices: talent acquisition, training methodologies, performance appraisals, wage structures, and compliance with Indian labor codes.",
        "syllabus": {
            "unit1": "Unit 1: HRM Concepts, Strategic Role, and Human Resource Planning (HRP)",
            "unit2": "Unit 2: Recruitment, Selection, Induction, and Placement Strategies",
            "unit3": "Unit 3: Training Needs Assessment (TNA) and Executive Development",
            "unit4": "Unit 4: Performance Appraisal Methods (360-degree, KPI, MBO) and Compensation",
            "unit5": "Unit 5: Industrial Relations, Collective Bargaining, and New Indian Labor Codes",
            "textbooks": [
                "K. Aswathappa, 'Human Resource Management: Text and Cases', McGraw Hill India.",
                "Gary Dessler & Biju Varkkey, 'Human Resource Management', Pearson India.",
                "P. Subba Rao, 'Personnel and Human Resource Management', Himalaya Publishing House."
            ]
        }
    },
    {
        "code": "BBA-501",
        "title": "Entrepreneurship",
        "name": "Entrepreneurship",
        "stream": "Business",
        "category": "Academic Elective (DSE)",
        "credits": "4 Credits (Theory: 4)",
        "degrees": ["BBA", "B.Com", "B.Tech", "BCA", "B.A."],
        "semesters": [3, 4, 5, 6, 7, 8],
        "career_goals": ["Entrepreneur", "Business Analyst", "Higher Studies"],
        "skills": ["Business Model Canvas (BMC)", "Pitch Deck Design", "Startup Valuation", "Indian Startup Schemes (DPIIT)", "Unit Economics"],
        "description": "Covers the complete entrepreneurial lifecycle in India: opportunity identification, lean startup methodology, bootstrapping, VC fundraising, and legal compliances.",
        "syllabus": {
            "unit1": "Unit 1: Entrepreneurship Ecosystem in India & DPIIT Startup Schemes",
            "unit2": "Unit 2: Idea Validation, Customer Discovery, and Business Model Canvas",
            "unit3": "Unit 3: Venture Financing, Angel Investors, and Term Sheet Fundamentals",
            "unit4": "Unit 4: Legal & Regulatory Framework (Incorporation, IP Protection, ESOPs)",
            "unit5": "Unit 5: Growth Marketing, Unit Economics, and Scaling Indian Ventures",
            "textbooks": [
                "Poornima M. Charantimath, 'Entrepreneurship Development and Small Business Enterprises', Pearson India.",
                "Eric Ries, 'The Lean Startup', Penguin Random House India.",
                "S.S. Khanka, 'Entrepreneurial Development', S. Chand & Company New Delhi."
            ]
        }
    },
    {
        "code": "BBA-502",
        "title": "Digital Marketing",
        "name": "Digital Marketing",
        "stream": "Business",
        "category": "Skill Enhancement Course (SEC)",
        "credits": "3 Credits (Theory: 2, Lab: 1)",
        "degrees": ["BBA", "B.Com", "BCA", "B.A."],
        "semesters": [3, 4, 5, 6, 7, 8],
        "career_goals": ["Business Analyst", "Entrepreneur", "Software Developer"],
        "skills": ["Google Analytics 4 (GA4)", "Search Engine Optimization (SEO)", "Social Media Campaigns", "Paid Ads & SEM", "Content Strategy"],
        "description": "Blends data analytics with marketing strategy: attribution modeling, social media paid campaigns, search engine optimization, and conversion optimization.",
        "syllabus": {
            "unit1": "Unit 1: Digital Marketing Ecosystem & Consumer Journey Mapping",
            "unit2": "Unit 2: Search Engine Optimization (On-Page, Off-Page, Technical SEO)",
            "unit3": "Unit 3: Search Engine Marketing (Google Ads, Keyword Bidding, Quality Score)",
            "unit4": "Unit 4: Social Media Marketing & Influencer Campaign Execution",
            "unit5": "Unit 5: Web Analytics with GA4 and Conversion Rate Optimization (CRO)",
            "textbooks": [
                "Seema Gupta, 'Digital Marketing', McGraw Hill India.",
                "Philip Kotler, Hermawan Kartajaya, Iwan Setiawan, 'Marketing 5.0', Wiley India.",
                "Avinash Kaushik, 'Web Analytics 2.0', Wiley India."
            ]
        }
    },

    # --------------------------------------------------------------------------
    # ARTS & HUMANITIES STREAM
    # (B.A., B.Com, BBA)
    # --------------------------------------------------------------------------
    {
        "code": "BA-301",
        "title": "Psychology",
        "name": "Psychology",
        "stream": "Arts",
        "category": "Academic Elective (DSE)",
        "credits": "4 Credits (Theory: 4)",
        "degrees": ["B.A."],
        "semesters": [1, 2, 3, 4, 5, 6],
        "career_goals": ["Higher Studies", "Business Analyst", "Government Jobs"],
        "skills": ["Cognitive Behavior Analysis", "Social Psychology Principles", "Personality Assessment", "Research Methodologies", "Psychological Interviewing"],
        "description": "Introduction to psychological theories: cognitive functions, perception, memory, personality development, social influences, and behavioral analysis.",
        "syllabus": {
            "unit1": "Unit 1: History, Evolution, and Research Methods in Psychology",
            "unit2": "Unit 2: Biological Basis of Behavior, Sensation, and Perception",
            "unit3": "Unit 3: Learning Theories (Classical & Operant Conditioning) and Memory",
            "unit4": "Unit 4: Theories of Personality, Intelligence, and Emotional Intelligence",
            "unit5": "Unit 5: Social Behavior, Group Dynamics, and Mental Health Awareness in India",
            "textbooks": [
                "Robert A. Baron & Girishwar Misra, 'Psychology', Pearson India.",
                "Morgan, King, Weisz, Schopler, 'Introduction to Psychology', McGraw Hill India.",
                "Ciccarelli & White, 'Psychology: South Asian Edition', Pearson India."
            ]
        }
    },
    {
        "code": "BA-302",
        "title": "Sociology",
        "name": "Sociology",
        "stream": "Arts",
        "category": "Academic Elective (DSE)",
        "credits": "4 Credits (Theory: 4)",
        "degrees": ["B.A.", "B.Com", "BBA"],
        "semesters": [1, 2, 3, 4, 5, 6],
        "career_goals": ["Government Jobs", "Higher Studies", "Business Analyst"],
        "skills": ["Social Structure Analysis", "Caste & Class Dynamics", "Social Change Evaluation", "Fieldwork & Survey Methods", "Policy Critique"],
        "description": "Sociological study of Indian society: institutions of family, kinship, caste, agrarian hierarchies, urbanization, and processes of modernization and globalization.",
        "syllabus": {
            "unit1": "Unit 1: Sociological Imagination, Basic Concepts (Society, Community, Institution)",
            "unit2": "Unit 2: Social Stratification in India: Caste, Class, Tribe, and Gender",
            "unit3": "Unit 3: Indian Village Communities, Agrarian Structure, and Urbanization",
            "unit4": "Unit 4: Processes of Social Change: Sanskritization, Westernization, Secularization",
            "unit5": "Unit 5: Contemporary Social Problems and Indian Constitutional Safeguards",
            "textbooks": [
                "M.N. Srinivas, 'Social Change in Modern India', Orient BlackSwan.",
                "Ram Ahuja, 'Society in India: Concepts, Theories and Recent Trends', Rawat Publications.",
                "C.N. Shankar Rao, 'Sociology of Indian Society', S. Chand New Delhi."
            ]
        }
    },
    {
        "code": "BA-501",
        "title": "Public Administration",
        "name": "Public Administration",
        "stream": "Arts",
        "category": "Academic Elective (DSE)",
        "credits": "4 Credits (Theory: 4)",
        "degrees": ["B.A.", "B.Com", "BBA"],
        "semesters": [3, 4, 5, 6, 7, 8],
        "career_goals": ["Government Jobs", "Higher Studies", "Business Analyst"],
        "skills": ["Administrative Machinery", "Public Policy Formulation", "RTI & Citizen Charters", "District Administration", "UPSC Civil Services Prep"],
        "description": "Detailed investigation of union and state administrative machinery in India, NITI Aayog policy architecture, district administration, and governance reforms.",
        "syllabus": {
            "unit1": "Unit 1: Public Administration Principles, Evolution, and New Public Management",
            "unit2": "Unit 2: Indian Administrative Framework (Cabinet Secretariat, PMO, Ministries)",
            "unit3": "Unit 3: District Administration, Collector Role, and Panchayati Raj (73rd/74th Amendments)",
            "unit4": "Unit 4: Accountability, RTI Act 2005, Lokpal, and E-Governance Initiatives",
            "unit5": "Unit 5: Administrative Reforms Commissions and Civil Service Neutrality",
            "textbooks": [
                "M. Laxmikanth, 'Public Administration', McGraw Hill Education India.",
                "B.L. Fadia & Kuldeep Fadia, 'Public Administration in India', Sahitya Bhawan Publications.",
                "Avasthi & Avasthi, 'Indian Administration', Lakshmi Narain Agarwal Agra."
            ]
        }
    },
    {
        "code": "BA-401",
        "title": "Journalism",
        "name": "Journalism",
        "stream": "Arts",
        "category": "Skill Enhancement Course (SEC)",
        "credits": "3 Credits (Theory: 2, Lab: 1)",
        "degrees": ["B.A.", "B.Com", "BBA"],
        "semesters": [2, 3, 4, 5, 6],
        "career_goals": ["Government Jobs", "Entrepreneur", "Higher Studies"],
        "skills": ["News Reporting & Feature Writing", "Media Ethics & Press Laws", "Broadcast Journalism", "Digital Journalism & Fact-Checking", "Press Council of India Guidelines"],
        "description": "Covers news reporting, feature writing, editorial ethics, media law (defamation, press freedom), broadcast news production, and digital journalism practices.",
        "syllabus": {
            "unit1": "Unit 1: Principles of Journalism, News Values, and Investigative Reporting",
            "unit2": "Unit 2: Writing for Print: Headlines, Leads, Inverted Pyramid Structure",
            "unit3": "Unit 3: Broadcast Journalism: TV News Bulletin Production and Anchoring",
            "unit4": "Unit 4: Media Laws & Ethics (Article 19(1)(a), Press Council of India, Defamation)",
            "unit5": "Unit 5: Digital Newsrooms, Citizen Journalism, and AI-Driven Fact-Checking",
            "textbooks": [
                "K.M. Shrivastava, 'News Reporting and Editing', Sterling Publishers New Delhi.",
                "M.V. Kamath, 'Professional Journalism', Vikas Publishing House.",
                "Vir Bala Aggarwal & V.S. Gupta, 'Handbook of Journalism and Mass Communication', Concept Publishing."
            ]
        }
    },
    {
        "code": "BA-303",
        "title": "Economics",
        "name": "Economics",
        "stream": "Arts",
        "category": "Academic Elective (DSE)",
        "credits": "4 Credits (Theory: 4)",
        "degrees": ["B.A.", "B.Com", "BBA"],
        "semesters": [1, 2, 3, 4, 5, 6, 7, 8],
        "career_goals": ["Government Jobs", "Business Analyst", "Higher Studies", "Accountant"],
        "skills": ["Macroeconomic Policy Analysis", "Monetary Policy Review (RBI)", "Union Budget Analysis", "Inflation & GDP Forecasting", "Agricultural & Industrial Policies"],
        "description": "Analytical study of Indian macroeconomics: fiscal policy, monetary policy frameworks of RBI, economic reforms post-1991, foreign trade, and development metrics.",
        "syllabus": {
            "unit1": "Unit 1: Macroeconomic Foundations: National Income, GDP, and Multiplier Analysis",
            "unit2": "Unit 2: Monetary Economics: Money Supply, Inflation Targeting, and RBI Role",
            "unit3": "Unit 3: Public Finance: Indian Fiscal Federalism, FRBM Act, and Budgetary Deficits",
            "unit4": "Unit 4: Indian Economic Reforms, Make in India, and Industrial Policy Dynamics",
            "unit5": "Unit 5: External Sector: Balance of Payments, Foreign Direct Investment, and WTO",
            "textbooks": [
                "Ramesh Singh, 'Indian Economy for Civil Services', McGraw Hill India.",
                "Uma Kapila, 'Indian Economy: Performance and Policies', Academic Foundation.",
                "H.L. Ahuja, 'Macroeconomics: Theory and Policy', S. Chand New Delhi."
            ]
        }
    }
]


def init_db():
    """
    Initialize SQLite database tables and insert sample electives data
    if the table is empty or does not exist.
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    # Create electives table with structured columns
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS electives (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE NOT NULL,
            title TEXT NOT NULL,
            name TEXT NOT NULL,
            stream TEXT NOT NULL,
            category TEXT NOT NULL,
            credits TEXT NOT NULL,
            degrees TEXT NOT NULL,
            semesters TEXT NOT NULL,
            career_goals TEXT NOT NULL,
            skills TEXT NOT NULL,
            description TEXT NOT NULL,
            syllabus TEXT NOT NULL
        )
    """)

    # Check if data already exists
    cursor.execute("SELECT COUNT(*) AS count FROM electives")
    row = cursor.fetchone()
    count = row["count"] if row else 0

    if count == 0:
        print("[DATABASE] Seeding sample Indian college electives into SQLite...")
        for item in SAMPLE_ELECTIVES:
            cursor.execute("""
                INSERT INTO electives (
                    code, title, name, stream, category, credits,
                    degrees, semesters, career_goals, skills, description, syllabus
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                item["code"],
                item["title"],
                item["name"],
                item["stream"],
                item["category"],
                item["credits"],
                json.dumps(item["degrees"]),
                json.dumps(item["semesters"]),
                json.dumps(item["career_goals"]),
                json.dumps(item["skills"]),
                item["description"],
                json.dumps(item["syllabus"])
            ))
        conn.commit()
        print(f"[DATABASE] Successfully inserted {len(SAMPLE_ELECTIVES)} sample electives.")
    else:
        print(f"[DATABASE] Database already contains {count} electives. Ready.")

    conn.close()


def get_all_electives():
    """
    Retrieve all electives from the database.
    Decodes stored JSON fields into Python lists/dictionaries.
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM electives ORDER BY id ASC")
    rows = cursor.fetchall()
    conn.close()

    electives = []
    for r in rows:
        electives.append({
            "id": r["id"],
            "code": r["code"],
            "title": r["title"],
            "name": r["name"],
            "stream": r["stream"],
            "category": r["category"],
            "credits": r["credits"],
            "degrees": json.loads(r["degrees"]),
            "semesters": json.loads(r["semesters"]),
            "career_goals": json.loads(r["career_goals"]),
            "careerGoals": json.loads(r["career_goals"]),  # frontend camelCase compatibility
            "skills": json.loads(r["skills"]),
            "description": r["description"],
            "syllabus": json.loads(r["syllabus"])
        })
    return electives


def get_electives_by_degree(degree, semester=None):
    """
    Fetch electives relevant to a specific degree programme and optionally semester.
    Strictly filters out electives not available for the selected degree programme.
    """
    all_electives = get_all_electives()
    filtered = []

    for item in all_electives:
        # Degree eligibility check
        if degree in item["degrees"]:
            if semester is not None:
                if int(semester) in item["semesters"]:
                    filtered.append(item)
            else:
                filtered.append(item)

    return filtered


def insert_elective(elective_dict):
    """
    Insert a new configurable elective into the database.
    Allows colleges to customize semester-wise elective structures.
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    degrees_json = json.dumps(elective_dict.get("degrees", []))
    semesters_json = json.dumps(elective_dict.get("semesters", []))
    career_goals_json = json.dumps(elective_dict.get("career_goals", []))
    skills_json = json.dumps(elective_dict.get("skills", []))
    syllabus_json = json.dumps(elective_dict.get("syllabus", {}))

    cursor.execute("""
        INSERT INTO electives (
            code, title, name, stream, category, credits,
            degrees, semesters, career_goals, skills, description, syllabus
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        elective_dict["code"],
        elective_dict["title"],
        elective_dict.get("name", elective_dict["title"]),
        elective_dict.get("stream", "General"),
        elective_dict.get("category", "Academic Elective (DSE)"),
        elective_dict.get("credits", "4 Credits"),
        degrees_json,
        semesters_json,
        career_goals_json,
        skills_json,
        elective_dict.get("description", ""),
        syllabus_json
    ))
    conn.commit()
    new_id = cursor.lastrowid
    conn.close()
    return new_id


if __name__ == "__main__":
    init_db()
    items = get_all_electives()
    print(f"Total electives loaded: {len(items)}")

