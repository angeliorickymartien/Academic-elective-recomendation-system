"""
app.py - Main Flask Application for Academic Elective Recommendation System
Indian Higher Education System (NEP 2020 & CBCS Aligned)

Endpoints:
1. GET  /                -> Serves the frontend web dashboard (index.html)
2. GET  /<path:filename> -> Serves frontend static assets (style.css, script.js)
3. GET  /api/health      -> Health check verifying backend status and database connection
4. GET  /api/electives   -> Returns list of all electives (optional filtering by degree & semester)
5. POST /api/recommend   -> Processes student academic profile and returns Top 3 matching electives

Run locally:
    python backend/app.py
Accessible at:
    http://127.0.0.1:5000
"""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import sys
import os

# Ensure backend directory is in python module search path
BACKEND_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(BACKEND_DIR)

# Path to the frontend directory
FRONTEND_DIR = os.path.abspath(os.path.join(BACKEND_DIR, "..", "frontend"))

from database import init_db, get_all_electives, get_electives_by_degree
from recommender import recommend_electives

# Initialize Flask Application
app = Flask(__name__, static_folder=None)

# Enable Cross-Origin Resource Sharing (CORS) across all origins and headers
CORS(app, resources={r"/*": {"origins": "*"}})

# Supported Indian Undergraduate Degree Programmes
SUPPORTED_DEGREES = [
    "BCA",
    "B.Sc Computer Science",
    "B.Com",
    "BBA",
    "B.A.",
    "B.Tech"
]

# Supported Career Goals
SUPPORTED_CAREER_GOALS = [
    "Software Developer",
    "Data Scientist",
    "AI Engineer",
    "Cyber Security Analyst",
    "Business Analyst",
    "Accountant",
    "Entrepreneur",
    "Government Jobs",
    "Higher Studies"
]


# ==============================================================================
# CORS & PRIVATE NETWORK ACCESS HEADERS
# ==============================================================================
@app.after_request
def apply_cors_headers(response):
    """
    Ensure all responses allow cross-origin requests, including file:/// origins
    and Chromium Private Network Access (PNA).
    """
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS, PUT, DELETE'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization, Accept, X-Requested-With'
    response.headers['Access-Control-Allow-Private-Network'] = 'true'
    return response


# ==============================================================================
# FRONTEND STATIC SERVING ROUTES (Same-Origin Web App)
# ==============================================================================
@app.route('/')
def serve_index():
    """Serve the main student portal dashboard at http://127.0.0.1:5000/"""
    return send_from_directory(FRONTEND_DIR, 'index.html')


@app.route('/<path:filename>')
def serve_static(filename):
    """Serve CSS, JS, and image assets from the frontend directory."""
    file_path = os.path.join(FRONTEND_DIR, filename)
    if os.path.isfile(file_path):
        return send_from_directory(FRONTEND_DIR, filename)
    # If not a static file, fallback to 404
    return jsonify({"error": "Resource not found"}), 404


# ==============================================================================
# ROUTE 1: HEALTH CHECK
# ==============================================================================
@app.route('/api/health', methods=['GET'])
def health_check():
    """
    GET /api/health
    Verifies that the Flask server and SQLite database are fully operational.
    """
    try:
        electives = get_all_electives()
        return jsonify({
            "status": "online",
            "message": "Academic Elective Recommendation System backend is running successfully.",
            "database": "connected (SQLite)",
            "total_electives_loaded": len(electives),
            "education_framework": "Indian Higher Education (NEP 2020 / CBCS)",
            "supported_degrees": SUPPORTED_DEGREES,
            "supported_semesters": "1 to 8"
        }), 200
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": f"Database error: {str(e)}"
        }), 500


# ==============================================================================
# ROUTE 2: GET ELECTIVES
# ==============================================================================
@app.route('/api/electives', methods=['GET'])
def get_electives():
    """
    GET /api/electives
    Returns a list of available Indian college electives.
    
    Optional Query Parameters:
    - degree:   Filter by programme (e.g. ?degree=B.Tech)
    - semester: Filter by semester (e.g. ?semester=5)
    """
    degree = request.args.get('degree')
    semester = request.args.get('semester')

    try:
        if degree:
            if semester:
                try:
                    sem_num = int(semester)
                except ValueError:
                    return jsonify({"error": "Semester must be an integer between 1 and 8"}), 400
                data = get_electives_by_degree(degree, sem_num)
            else:
                data = get_electives_by_degree(degree)
        else:
            data = get_all_electives()

        return jsonify({
            "status": "success",
            "count": len(data),
            "filter_applied": {
                "degree": degree,
                "semester": semester
            },
            "electives": data
        }), 200
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": f"Failed to retrieve electives: {str(e)}"
        }), 500


# ==============================================================================
# ROUTE 3: RECOMMEND ELECTIVES (CORE ENDPOINT)
# ==============================================================================
@app.route('/api/recommend', methods=['POST', 'OPTIONS'])
def recommend():
    """
    POST /api/recommend
    Accepts student information and returns Top 3 matching electives.
    Also handles OPTIONS preflight requests.
    """
    # Handle preflight OPTIONS request
    if request.method == 'OPTIONS':
        return ('', 204)

    # 1. Parse incoming JSON body
    data = request.get_json(silent=True)
    if not data:
        return jsonify({
            "status": "fail",
            "error": "No JSON payload provided in request body."
        }), 400

    # 2. Extract input fields (handling both camelCase and snake_case)
    name = (data.get("name") or data.get("studentName") or "").strip()
    degree = (data.get("degree") or data.get("degreeProgramme") or "").strip()
    semester_raw = data.get("semester") or data.get("currentSemester")
    career_goal = (data.get("careerGoal") or data.get("career_goal") or "").strip()
    interests = data.get("interests") or data.get("academicInterests") or []
    skills = data.get("skills") or data.get("technicalSkills") or []
    favourite_subjects = (data.get("favouriteSubjects") or data.get("favourite_subjects") or "").strip()

    # Convert comma-separated strings to list if sent as string
    if isinstance(interests, str):
        interests = [item.strip() for item in interests.split(",") if item.strip()]
    if isinstance(skills, str):
        skills = [item.strip() for item in skills.split(",") if item.strip()]

    # 3. Input Validation
    errors = []

    if not name:
        errors.append("Student Name is required.")

    if not degree:
        errors.append("Degree Programme is required.")
    elif degree not in SUPPORTED_DEGREES:
        errors.append(f"Invalid Degree Programme '{degree}'. Supported: {', '.join(SUPPORTED_DEGREES)}")

    if semester_raw is None:
        errors.append("Current Semester is required.")
    else:
        try:
            semester = int(semester_raw)
            if semester < 1 or semester > 8:
                errors.append("Current Semester must be between 1 and 8.")
        except (ValueError, TypeError):
            errors.append("Current Semester must be a valid integer between 1 and 8.")
            semester = 1

    if not career_goal:
        errors.append("Career Goal is required.")
    elif career_goal not in SUPPORTED_CAREER_GOALS:
        errors.append(f"Invalid Career Goal '{career_goal}'. Supported: {', '.join(SUPPORTED_CAREER_GOALS)}")

    if not interests:
        errors.append("At least one Academic Interest must be selected.")

    if not skills:
        errors.append("At least one Technical Skill must be selected.")

    if not favourite_subjects:
        errors.append("Favourite Subjects must be specified.")

    # Return descriptive validation error if any check failed
    if errors:
        return jsonify({
            "status": "fail",
            "error": "Input validation failed.",
            "details": errors
        }), 400

    # 4. Construct normalized student profile
    student_profile = {
        "name": name,
        "degree": degree,
        "semester": semester,
        "careerGoal": career_goal,
        "career_goal": career_goal,
        "interests": interests,
        "skills": skills,
        "favouriteSubjects": favourite_subjects,
        "favourite_subjects": favourite_subjects
    }

    # 5. Run rule-based recommendation algorithm
    try:
        top_recommendations = recommend_electives(student_profile)

        return jsonify({
            "status": "success",
            "message": f"Successfully generated top {len(top_recommendations)} recommendations for {name}.",
            "student": {
                "name": name,
                "degree": degree,
                "semester": semester,
                "careerGoal": career_goal
            },
            "recommendations": top_recommendations
        }), 200

    except Exception as e:
        return jsonify({
            "status": "error",
            "message": f"Recommendation engine error: {str(e)}"
        }), 500


# ==============================================================================
# ERROR HANDLERS
# ==============================================================================
@app.errorhandler(404)
def not_found(e):
    return jsonify({
        "status": "error",
        "error": "Resource not found",
        "available_endpoints": [
            "GET  /",
            "GET  /api/health",
            "GET  /api/electives",
            "POST /api/recommend"
        ]
    }), 404


# ==============================================================================
# MAIN APPLICATION ENTRY POINT
# ==============================================================================
if __name__ == '__main__':
    # Initialize SQLite database and seed sample electives
    init_db()

    print("\n" + "=" * 70)
    print("  ACADEMIC ELECTIVE RECOMMENDATION SYSTEM - BACKEND (FLASK + SQLITE)")
    print("  Framework: Indian Higher Education System (NEP 2020 / CBCS)")
    print("=" * 70)
    print("  * Student Portal:   http://127.0.0.1:5000/")
    print("  * Health Check:     http://127.0.0.1:5000/api/health")
    print("  * Electives List:   http://127.0.0.1:5000/api/electives")
    print("  * Recommendation:   POST http://127.0.0.1:5000/api/recommend")
    print("=" * 70 + "\n")

    # Start local Flask development server
    app.run(host='127.0.0.1', port=5000, debug=True)
