@echo off
title Academic Elective Recommendation System - Launcher
color 0B

echo ======================================================================
echo    Academic Elective Recommendation System (NEP 2020 / CBCS)
echo    College Mini-Project - Single Click System Launcher
echo ======================================================================
echo.

:: 1. Detect Python executable (python or py)
set PY_CMD=
python --version >nul 2>&1
if %errorlevel% equ 0 (
    set PY_CMD=python
) else (
    py --version >nul 2>&1
    if %errorlevel% equ 0 (
        set PY_CMD=py
    )
)

if "%PY_CMD%"=="" (
    echo [ERROR] Python is not installed or not added to your system PATH!
    echo Please install Python 3.8 or higher from https://www.python.org/
    echo Make sure to check the box "Add Python to PATH" during installation.
    echo.
    pause
    exit /b 1
)

echo [1/3] Python detected: %PY_CMD%
echo.

:: 2. Check if dependencies are already installed
echo [2/3] Checking dependencies (Flask, Flask-Cors)...
%PY_CMD% -c "import flask, flask_cors" >nul 2>&1
if %errorlevel% neq 0 (
    echo Installing required packages from requirements.txt...
    %PY_CMD% -m pip install -r "%~dp0requirements.txt"
    if %errorlevel% neq 0 (
        echo [WARNING] Pip install encountered an issue. Trying direct package install...
        %PY_CMD% -m pip install flask flask-cors
    )
) else (
    echo Dependencies (Flask, Flask-Cors) are already installed.
)
echo.

:: 3. Launch Flask Backend Server in a dedicated command window
echo [3/3] Starting Flask Backend Server at http://127.0.0.1:5000 ...
start "Academic Elective Recommendation System - Backend API" cmd /k "cd /d \"%~dp0backend\" && %PY_CMD% app.py"

:: Wait 2 seconds for server initialization
echo Waiting for server to initialize...
timeout /t 2 /nobreak >nul

:: 4. Launch browser directly to the web application
echo.
echo Opening Student Portal in your web browser: http://127.0.0.1:5000 ...
start http://127.0.0.1:5000

echo.
echo ======================================================================
echo    SYSTEM IS NOW RUNNING SUCCESSFULLY!
echo.
echo    * Web Portal:   http://127.0.0.1:5000/
echo    * Health Check: http://127.0.0.1:5000/api/health
echo    * Electives:    http://127.0.0.1:5000/api/electives
echo    * Recommend:    POST http://127.0.0.1:5000/api/recommend
echo.
echo    Keep the Backend command prompt window open during your demo.
echo    To stop the server, simply close the Backend command prompt.
echo ======================================================================
echo.
pause
