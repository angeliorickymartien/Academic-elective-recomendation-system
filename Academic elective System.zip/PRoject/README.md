# Academic Elective Recommendation System
> **College Mini-Project | Indian Higher Education System (NEP 2020 & CBCS Aligned)**

A complete, modern, and professional web-based academic advisory platform built specifically for Indian undergraduate college students. The system guides students in selecting **Academic Electives (Discipline-Specific Electives)**, **Open Electives (Generic Electives)**, and **Skill Enhancement Courses (SEC)** based on their enrolled degree programme, current semester, technical skills, interests, and future career goals.

---

## 🎯 1. Project Introduction & Objectives

### Introduction
In Indian higher education institutions (HEIs) governed by the University Grants Commission (**UGC**) and **AICTE**, the Choice Based Credit System (**CBCS**) and the National Education Policy (**NEP 2020**) grant undergraduate students the autonomy to choose elective courses across multidisciplinary baskets.

However, students often select electives randomly, due to peer pressure or seeking easy passing marks, without assessing whether the subject complements their career destinations or prepares them for placements and competitive examinations like GATE, CAT, or Civil Services.

The **Academic Elective Recommendation System** solves this problem by providing transparent, rule-based, and career-aligned recommendations tailored to each student's semester level and technical background.

### Key Objectives
1. **Curriculum Guidance:** Recommend electives strictly compliant with Indian undergraduate degree programmes (BCA, B.Sc Computer Science, B.Com, BBA, B.A., B.Tech) and semester structures (1 to 8).
2. **Career Alignment:** Map student competencies to future aspirations (Software Developer, Data Scientist, AI Engineer, Cyber Security Analyst, Business Analyst, Accountant, Entrepreneur, Government Jobs, Higher Studies).
3. **Data-Driven Match Scoring:** Calculate authentic match percentage scores and display them with interactive progress bars.
4. **Transparent Rationales:** Provide clear explanations justifying why a subject was recommended and highlight the specific skills students will acquire.
5. **Configurability:** Store elective offerings in a lightweight SQLite database so different Indian colleges can easily adjust semester baskets and syllabus outlines.

---

## 💻 2. Technologies Used

- **Frontend:**
  - **HTML5:** Semantic markup, accessible forms, responsive layout.
  - **CSS3:** Custom properties (CSS variables), modern blue and white academic theme, Flexbox, CSS Grid, animations, and `@media print` advisory slip styling.
  - **Vanilla JavaScript (ES6+):** Form validation, asynchronous API communication via `fetch()`, interactive multi-select chips, progress bar rendering, and modal management.
  - *(Zero heavy frontend frameworks like React, Angular, or Vue; zero Bootstrap dependencies).*
- **Backend:**
  - **Python 3.8+**
  - **Flask:** Lightweight WSGI micro-framework for serving the REST API.
  - **Flask-CORS:** Cross-Origin Resource Sharing enabling direct browser communication.
- **Database:**
  - **SQLite3:** Embedded relational database storing elective details, syllabus units, and Indian reference textbooks.

---

## 🏗️ 3. System Architecture

```
                  +----------------------------------------------+
                  |               STUDENT BROWSER                |
                  |     (HTML5 + CSS3 + Vanilla JavaScript)      |
                  +----------------------------------------------+
                                         |
                       POST /api/recommend (JSON Payload)
                                         |
                                         v
                  +----------------------------------------------+
                  |             FLASK REST API SERVER            |
                  |                   (app.py)                   |
                  +----------------------------------------------+
                     |                         |
                     v                         v
        +-------------------------+   +-------------------------+
        |   RECOMMENDER ENGINE    |   |     SQLITE DATABASE     |
        |    (recommender.py)     |   |      (database.py)      |
        |                         |   |     (electives.db)      |
        | - Degree Gating Filter  |<--|                         |
        | - Semester Eligibility  |   | 24 Sample Electives:    |
        | - Career Goal Alignment |   | - Computer Science      |
        | - Skill & Interest Match|   | - Commerce & Accounting |
        | - Score Normalization   |   | - Business & Management |
        +-------------------------+   | - Arts & Humanities     |
                     |                +-------------------------+
                     v
        +-------------------------+
        |   TOP 3 RECOMMENDATIONS |
        | - Match Percentages (%) |
        | - Syllabus Modules      |
        | - Actionable Rationales |
        +-------------------------+
                     |
        HTTP 200 JSON Response Payload
                     |
                     v
                  +----------------------------------------------+
                  |              RESULTS DASHBOARD               |
                  |  - Match Progress Bars & Skill Badges        |
                  |  - 5-Unit CBCS Syllabus Viewer Modal         |
                  |  - Printable Academic Advisory Slip          |
                  +----------------------------------------------+
```

---

## 🧠 4. How the Recommendation Algorithm Works

The recommendation engine (`recommender.py`) evaluates candidate electives through an objective multi-factor scoring formula:

1. **Strict Degree Programme Filter (Prerequisite Gate):**
   - Only courses officially offered for the student's degree programme (e.g., B.Tech, BCA, B.Com, etc.) are considered. Incompatible degree electives are excluded immediately.
2. **Semester Eligibility (+20 points):**
   - Verifies whether the course is scheduled for the student's current semester (1 to 8). Adjacent semester electives receive partial points (+10 points).
3. **Career Goal Alignment (+35 points - Highest Weight):**
   - Matches the student's target career destination (e.g., Software Developer, AI Engineer, Accountant, Govt Jobs) against the elective's career mapping.
4. **Academic Interests Overlap (Up to +30 points):**
   - Compares the student's selected academic interests with the elective's subject domain, description, and keywords.
5. **Technical Skills Overlap (Up to +24 points):**
   - Compares student technical tools and programming languages with the practical syllabus outcomes.
6. **Favourite Subjects Affinity (+12 points):**
   - Identifies whether core subjects previously studied provide a solid foundation for this elective.
7. **Score Normalization:**
   - Raw scores are mapped to a realistic percentage score between 75% and 98% and sorted to extract the **Top 3** matching courses.

---

## 📁 5. Complete Project File Structure

```text
PRoject/
├── backend/
│   ├── app.py               # Flask REST API server with routes & CORS
│   ├── database.py          # SQLite database manager & dataset seeder
│   ├── recommender.py       # Rule-based recommendation engine
│   ├── requirements.txt     # Python backend dependencies
│   ├── test_api.py          # Automated REST API unit tests
│   └── test_recommender.py  # Standalone recommendation logic test script
├── frontend/
│   ├── index.html           # Student portal dashboard
│   ├── style.css            # Modern blue & white responsive stylesheet
│   └── script.js            # Frontend JavaScript connecting to /api/recommend
├── requirements.txt         # Root-level Python dependencies
├── run.bat                  # Single-click launcher for Windows
└── README.md                # Project documentation
```

---

## 🚀 6. Installation & Beginner Step-by-Step Guide

### Method A: Single-Click Launch (Recommended for Windows)

1. Double-click the file **`run.bat`** in the project folder.
2. The batch script will automatically:
   - Check your Python installation.
   - Install required packages (`Flask` and `Flask-Cors`).
   - Start the Flask backend server at `http://127.0.0.1:5000`.
   - Open `frontend/index.html` in your default web browser.

---

### Method B: Manual Step-by-Step Launch

#### Step 1: Install Python Dependencies
Open PowerShell or Command Prompt, navigate to the project directory, and run:
```bash
cd c:\PRoject
pip install -r requirements.txt
```

#### Step 2: Start the Flask Backend Server
```bash
python backend/app.py
```
You will see:
```text
======================================================================
  ACADEMIC ELECTIVE RECOMMENDATION SYSTEM - BACKEND (FLASK + SQLITE)
  Framework: Indian Higher Education System (NEP 2020 / CBCS)
======================================================================
  * Server running at: http://127.0.0.1:5000
  * Health Check:      http://127.0.0.1:5000/api/health
  * Electives List:    http://127.0.0.1:5000/api/electives
  * Recommendation:    POST http://127.0.0.1:5000/api/recommend
======================================================================
```

#### Step 3: Open the Frontend Portal
- Keep the backend terminal running.
- In your file explorer, navigate to the `frontend/` folder and double-click **`index.html`** (or open it in Google Chrome, Edge, or Firefox).

#### Step 4: Generate Recommendations
1. Enter your **Student Name** (e.g. `Rohan Sharma`).
2. Select your **Degree Programme** (e.g. `BCA` or `B.Tech`).
3. Select your **Current Semester** (1 to 8).
4. Click to select your **Academic Interests** and **Technical Skills**.
5. Enter or select your **Favourite Subjects**.
6. Choose your **Primary Career Goal** (e.g. `Software Developer`).
7. Click **"Generate Elective Recommendations"**.
8. View the Top 3 recommended electives with animated **Match Score Progress Bars**, why each subject was recommended, and click **"View Detailed Syllabus"** to see unit-wise modules!

---

## 🧪 7. Running Backend Unit Tests

You can verify the backend independently by running:

```bash
# 1. Test recommendation engine with different Indian degree profiles:
python backend/test_recommender.py

# 2. Test all Flask API endpoints and validation error handling:
python backend/test_api.py
```

---

## 📜 8. Academic Compliance & Terminology

- **Compliant Authorities:** University Grants Commission (UGC) Guidelines on Choice Based Credit System (CBCS) & National Education Policy (NEP 2020).
- **Terminology:** Degree Programme, Academic Year, Semester, Academic Elective (DSE), Open Elective (GE), Skill Enhancement Course (SEC), Career Goals.
- **Zero American Terminology:** Does not use GPA, majors, SAT, or community colleges.
